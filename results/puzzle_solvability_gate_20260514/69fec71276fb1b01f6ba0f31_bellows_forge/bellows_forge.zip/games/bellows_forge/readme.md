# Bellows Forge

## Overview

Bellows Forge is a grid-based pressure orchestration puzzle. The forge floor
contains bellows, chambers, vents, equalizers, and molds. Later levels introduce
regulators that shift pressure between local forge cells and must be coordinated
with compression, equalization, and venting. Very Hard introduces crucibles that
convert prepared chamber pressure into molds. Activations change visible
pressure stacks, and the player learns the accepted mold state through visual
feedback and level advancement.

## Category and Style

- Category: Orchestration
- Style: VOC, Volume Orchestration

## Difficulty Levers Used

1. Action Coupling: bellows, vents, equalizers, regulators, and crucibles affect
   multiple pressure cells or coordinated local groups at once.
2. Non-Commutativity: compressing before releasing creates a different state
   than releasing before compressing.
3. Hidden Constraints: mold acceptance is shown visually instead of described
   by exact numeric rules in the interface.
4. Transformation Chain: pressure must be compressed into chambers,
   redistributed, regulated or converted, and then released from the working
   area.
5. Map Topology: the number and placement of chamber and mold rows changes how
   the cursor moves and how local areas overlap.

## Interaction Modes

### Mouse Mode

Click a forge cell to select and activate it.

### Keyboard Mode

- `WASD` or arrow keys: move the cursor between forge cells
- `Space` or `F`: activate the selected cell
- `R`: development reset

## Win Condition

Complete all four levels by stabilizing every mold while clearing excess
pressure from the working chambers. The accepted state is communicated through
the mold visuals and level completion.

## Verification

Run:

```bash
python verify.py
```

The verifier checks deterministic generation across seeds, BFS solvability,
solution length ranges, pressure capacity invariants, blocked actions, engine
replay, reset replay, visible object usefulness, generated variation, and
source cleanup.

## Run Game

Run:

```bash
python run.py
```

Then open:

```txt
http://127.0.0.1:5000
```

## Deterministic Procedural Generation

Forge layouts are generated with seeded `random.Random(...)`. The same seed,
level index, and reset count reproduce the same object placement, pressure
targets, local action areas, and starting state. Development resets produce
different deterministic variants for replay testing.
