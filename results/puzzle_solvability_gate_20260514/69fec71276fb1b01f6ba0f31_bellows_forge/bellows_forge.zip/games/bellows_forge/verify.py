"""Verify Bellows Forge procedural generation and pressure mechanics.

Run:
    python verify.py
"""

from __future__ import annotations

import ast
from collections import defaultdict, deque
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parent.parent.parent
HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(HERE))

from bellows_forge import (
    LEVEL_CONFIGS,
    BellowsForge,
    PlanAction,
    abstract_actions,
    cursor_neighbor,
    generate_spec,
    initial_state,
    is_solved,
    solve_spec,
    spec_signature,
    transition,
)
from ipe.enums import ActionInput, GameAction


SEEDS = range(20)
RESET_SANITY_REPLAYS = 2
ENGINE_REPLAY_SEEDS = range(5)


def _metrics(spec) -> dict[str, int]:
    xs = [cell.pos[0] for cell in spec.cells]
    ys = [cell.pos[1] for cell in spec.cells]
    return {
        "objects": len(spec.cells),
        "chambers": len(spec.chamber_indices),
        "molds": len(spec.mold_indices),
        "bellows": sum(1 for cell in spec.cells if cell.kind == "bellow"),
        "vents": sum(1 for cell in spec.cells if cell.kind == "vent"),
        "equalizers": sum(1 for cell in spec.cells if cell.kind == "equalizer"),
        "regulators": sum(1 for cell in spec.cells if cell.kind == "regulator"),
        "crucibles": sum(1 for cell in spec.cells if cell.kind == "crucible"),
        "target": spec.target_pressure,
        "bbox_area": (max(xs) - min(xs) + 1) * (max(ys) - min(ys) + 1),
    }


def _topology_signature(spec) -> tuple:
    return tuple((cell.kind, cell.pos, cell.capacity, cell.target, cell.zone) for cell in spec.cells)


def _cursor_path(spec, start: int, target: int) -> list[GameAction] | None:
    if start == target:
        return []
    moves = [
        (GameAction.ACTION1, 0, -1),
        (GameAction.ACTION2, 0, 1),
        (GameAction.ACTION3, -1, 0),
        (GameAction.ACTION4, 1, 0),
    ]
    q = deque([(start, [])])
    seen = {start}
    while q:
        cursor, path = q.popleft()
        for action, dx, dy in moves:
            nxt = cursor_neighbor(spec, cursor, dx, dy)
            if nxt == cursor or nxt in seen:
                continue
            new_path = path + [action]
            if nxt == target:
                return new_path
            seen.add(nxt)
            q.append((nxt, new_path))
    return None


def _engine_actions_for_solution(spec, solution: list[PlanAction]) -> list[GameAction] | None:
    cursor = spec.cursor_start
    actions: list[GameAction] = []
    for plan in solution:
        if plan.index is None:
            return None
        path = _cursor_path(spec, cursor, plan.index)
        if path is None:
            return None
        actions.extend(path)
        actions.append(GameAction.ACTION5)
        cursor = plan.index
    return actions


def _replay_logic(spec, solution: list[PlanAction]) -> tuple[bool, str]:
    state = initial_state(spec)
    previous_total = sum(state.pressure)
    for plan in solution:
        next_state, changed = transition(spec, state, plan)
        if not changed:
            return False, f"solution contains blocked action {plan}"
        for value, cell in zip(next_state.pressure, spec.cells):
            if value < 0 or value > cell.capacity:
                return False, f"capacity violation at {cell.pos}: {value}/{cell.capacity}"
        total = sum(next_state.pressure)
        kind = spec.cells[plan.index].kind if plan.index is not None else ""
        if kind == "bellow" and total <= previous_total:
            return False, "compression did not increase pressure"
        if kind == "vent" and total >= previous_total:
            return False, "release did not reduce pressure"
        if kind == "equalizer" and total != previous_total:
            return False, "equalizer changed total pressure"
        if kind == "regulator" and total != previous_total:
            return False, "regulator changed total pressure"
        if kind == "crucible" and total != previous_total:
            return False, "crucible changed total pressure"
        previous_total = total
        state = next_state
    if not is_solved(spec, state):
        return False, "solution did not reach accepted forge state"
    return True, "ok"


def _blocked_actions_preserve_state(spec) -> tuple[bool, str]:
    state = initial_state(spec)
    for idx in spec.mold_indices:
        next_state, changed = transition(spec, state, PlanAction("activate", idx))
        if changed or next_state != state:
            return False, "mold activation changed state"
    for action in abstract_actions(spec):
        next_state, changed = transition(spec, state, action)
        if not changed and next_state != state:
            return False, f"blocked action mutated state: {action}"
    for idx, cell in enumerate(spec.cells):
        if cell.kind == "vent":
            next_state, changed = transition(spec, state, PlanAction("activate", idx))
            if changed or next_state != state:
                return False, "empty release activation changed state"
    return True, "ok"


def _visible_objects_meaningful(spec, solution: list[PlanAction]) -> tuple[bool, str]:
    activated = {plan.index for plan in solution if plan.index is not None}
    equalizer_zones = [cell.zone for cell in spec.cells if cell.kind == "equalizer"]
    active_zones = [
        cell.zone for cell in spec.cells
        if cell.kind in {"bellow", "vent", "equalizer", "regulator", "crucible"}
    ]
    for idx, cell in enumerate(spec.cells):
        if cell.kind in {"bellow", "vent", "equalizer", "regulator", "crucible"} and idx not in activated:
            return False, f"{cell.kind} at {cell.pos} not used in solution"
        if cell.kind == "chamber" and not any(idx in zone for zone in active_zones):
            return False, f"chamber at {cell.pos} is outside every active area"
        if cell.kind == "mold":
            if cell.target <= 0 or not any(idx in zone for zone in equalizer_zones):
                return False, f"mold at {cell.pos} is outside every acceptance area"
    return True, "ok"


def _solve_with_disabled_kind(spec, disabled_kind: str, max_nodes: int = 100_000) -> list[PlanAction] | None:
    if disabled_kind == "crucible":
        for cell in spec.cells:
            if cell.kind == "crucible" and not any(
                other.kind == "regulator" and other.zone == cell.zone
                for other in spec.cells
            ):
                return None
    if disabled_kind == "regulator":
        for cell in spec.cells:
            if cell.kind == "regulator" and not any(
                other.kind == "crucible" and other.zone == cell.zone
                for other in spec.cells
            ):
                return None
    start = initial_state(spec)
    q = deque([(start, [])])
    seen = {start}
    actions = [
        action for action in abstract_actions(spec)
        if action.index is not None and spec.cells[action.index].kind != disabled_kind
    ]
    nodes = 0
    while q:
        state, path = q.popleft()
        nodes += 1
        if nodes > max_nodes:
            return None
        for action in actions:
            next_state, changed = transition(spec, state, action)
            if not changed or next_state == state:
                continue
            next_path = path + [action]
            if is_solved(spec, next_state):
                return next_path
            if next_state not in seen:
                seen.add(next_state)
                q.append((next_state, next_path))
    return None


def _regulator_usage_ok(
    spec,
    solution: list[PlanAction],
    level_index: int,
) -> tuple[bool, str, int]:
    regulator_indices = [idx for idx, cell in enumerate(spec.cells) if cell.kind == "regulator"]
    regulator_activations = sum(1 for plan in solution if plan.index in regulator_indices)
    if level_index < 2:
        if regulator_indices:
            return False, "regulator appeared before Hard", regulator_activations
        return True, "ok", regulator_activations
    if not regulator_indices:
        return False, "Hard/Very Hard spec has no regulator", regulator_activations
    missing = [idx for idx in regulator_indices if all(plan.index != idx for plan in solution)]
    if missing:
        return False, f"regulator(s) not activated: {missing}", regulator_activations
    if _solve_with_disabled_kind(spec, "regulator") is not None:
        return False, "regulator-disabled search still solved level", regulator_activations
    return True, "ok", regulator_activations


def _crucible_usage_ok(
    spec,
    solution: list[PlanAction],
    level_index: int,
) -> tuple[bool, str, int]:
    crucible_indices = [idx for idx, cell in enumerate(spec.cells) if cell.kind == "crucible"]
    crucible_activations = sum(1 for plan in solution if plan.index in crucible_indices)
    if level_index < 3:
        if crucible_indices:
            return False, "crucible appeared before Very Hard", crucible_activations
        return True, "ok", crucible_activations
    if not crucible_indices:
        return False, "Very Hard spec has no crucible", crucible_activations
    missing = [idx for idx in crucible_indices if all(plan.index != idx for plan in solution)]
    if missing:
        return False, f"crucible(s) not activated: {missing}", crucible_activations
    if _solve_with_disabled_kind(spec, "crucible") is not None:
        return False, "crucible-disabled search still solved level", crucible_activations
    return True, "ok", crucible_activations


def _engine_replay(seed: int, level_index: int, actions: list[GameAction]) -> tuple[bool, str]:
    game = BellowsForge(seed=seed)
    if level_index:
        game.set_level(level_index)
    for action in actions:
        result = game.perform_action(ActionInput(id=action))
        if result.game_id != "bellows_forge":
            return False, "wrong game id in replay"
    if game._score != 1:
        return False, f"level did not complete exactly once; score={game._score}"
    return True, "ok"


def _reset_replay(seed: int, reset_count: int) -> tuple[bool, str, int, int]:
    game = BellowsForge(seed=seed)
    for _ in range(reset_count):
        game.perform_action(ActionInput(id=GameAction.RESET))
    expected = generate_spec(seed, 0, reset_count)
    if spec_signature(game._spec) != spec_signature(expected):
        return False, "reset deterministic signature mismatch", 0, 0
    solution = solve_spec(expected)
    if solution is None:
        return False, "reset variant has no solution", 0, 0
    actions = _engine_actions_for_solution(expected, solution)
    if actions is None:
        return False, "reset variant has no keyboard path", len(solution), 0
    for action in actions:
        game.perform_action(ActionInput(id=action))
    if game._score != 1:
        return False, "reset variant replay did not complete", len(solution), len(actions)
    return True, "ok", len(solution), len(actions)


def _full_game_replay(seed: int, reset_count: int = 0) -> tuple[bool, str, list[int], int]:
    game = BellowsForge(seed=seed)
    for _ in range(reset_count):
        game.perform_action(ActionInput(id=GameAction.RESET))

    bfs_lengths: list[int] = []
    keyboard_total = 0
    for _ in LEVEL_CONFIGS:
        solution = solve_spec(game._spec)
        if solution is None:
            return False, "level has no solution during full replay", bfs_lengths, keyboard_total
        actions = _engine_actions_for_solution(game._spec, solution)
        if actions is None:
            return False, "level has no keyboard replay path during full replay", bfs_lengths, keyboard_total
        bfs_lengths.append(len(solution))
        keyboard_total += len(actions)
        expected_score = game._score + 1
        for action in actions:
            game.perform_action(ActionInput(id=action))
        if game._score != expected_score:
            return False, "full replay did not advance exactly one level", bfs_lengths, keyboard_total
    return True, "ok", bfs_lengths, keyboard_total


def _scan_sources() -> tuple[bool, str]:
    banned_parts = [
        ("reser", "voir"),
        ("we", "ave"),
        ("ba", "sin"),
        ("val", "ve"),
        ("ga", "te"),
        ("ter", "minal"),
        ("pi", "pe"),
        ("pulse", "_loom"),
    ]
    for path in [HERE / "bellows_forge.py", HERE / "run.py", HERE / "readme.md"]:
        text = path.read_text(encoding="utf-8").lower()
        for left, right in banned_parts:
            if left + right in text:
                return False, f"stale copied-concept token in {path.name}"

    tree = ast.parse((HERE / "bellows_forge.py").read_text(encoding="utf-8"))
    for node in ast.walk(tree):
        if isinstance(node, ast.Attribute):
            if isinstance(node.value, ast.Name) and node.value.id == "random" and node.attr != "Random":
                return False, f"unscoped random.{node.attr} reference"
            if isinstance(node.value, ast.Name) and node.value.id == "os" and node.attr == "urandom":
                return False, "os.urandom reference"
        if isinstance(node, ast.Name) and node.id == "SystemRandom":
            return False, "SystemRandom reference"

    games_dir = HERE.parent
    for leftover in ["game_template", "CST_01"]:
        if (games_dir / leftover).exists():
            return False, f"template/example leftover present: {leftover}"
    return True, "ok"


def _range(values: list[int]) -> str:
    return f"{min(values)}-{max(values)}"


def main() -> int:
    issues: list[str] = []
    print("Bellows Forge verification")
    print(f"Seeds tested: {SEEDS.start}-{SEEDS.stop - 1} ({len(SEEDS)} total)")
    print(f"Levels checked per seed: {len(LEVEL_CONFIGS)}")
    print(f"Reset sanity replay count: {RESET_SANITY_REPLAYS}")

    ok, message = _scan_sources()
    if not ok:
        issues.append(message)

    signatures = set()
    topologies_by_level: dict[str, set[tuple]] = defaultdict(set)
    fingerprints_by_level: dict[str, set[tuple[int | None, ...]]] = defaultdict(set)
    metrics_by_level: dict[str, dict[str, list[int]]] = {
        config.name: defaultdict(list) for config in LEVEL_CONFIGS
    }
    solution_lengths: dict[str, list[int]] = {config.name: [] for config in LEVEL_CONFIGS}
    keyboard_counts: dict[str, list[int]] = {config.name: [] for config in LEVEL_CONFIGS}
    regulator_activations_by_level: dict[str, list[int]] = {config.name: [] for config in LEVEL_CONFIGS}
    regulator_disabled_failures_by_level: dict[str, int] = {config.name: 0 for config in LEVEL_CONFIGS}
    crucible_activations_by_level: dict[str, list[int]] = {config.name: [] for config in LEVEL_CONFIGS}
    crucible_disabled_failures_by_level: dict[str, int] = {config.name: 0 for config in LEVEL_CONFIGS}
    per_seed_lengths: dict[int, list[int]] = {}
    engine_bfs_lengths: list[int] = []
    engine_keyboard_counts: list[int] = []
    reset_bfs_lengths: list[int] = []
    reset_keyboard_counts: list[int] = []
    sampled_engine_replays_checked = 0
    sampled_engine_replay_failures = 0
    sampled_reset_replays_checked = 0
    sampled_reset_replay_failures = 0
    reset_signature_matches = 0
    specs_tested = 0

    for seed in SEEDS:
        seed_failures = 0
        lengths_for_seed: list[int] = []
        reset_signatures = set()

        for level_index, config in enumerate(LEVEL_CONFIGS):
            try:
                spec_a = generate_spec(seed, level_index, 0)
                spec_b = generate_spec(seed, level_index, 0)
                specs_tested += 1
                if spec_signature(spec_a) != spec_signature(spec_b):
                    raise AssertionError("nondeterministic generation")

                solution = solve_spec(spec_a)
                if solution is None:
                    raise AssertionError("no solution")
                if not (spec_a.min_steps <= len(solution) <= spec_a.max_steps):
                    raise AssertionError(f"solution length {len(solution)} outside range")
                ok, message, regulator_activations = _regulator_usage_ok(spec_a, solution, level_index)
                if not ok:
                    raise AssertionError(message)
                if level_index >= 2:
                    regulator_disabled_failures_by_level[config.name] += 1
                ok, message, crucible_activations = _crucible_usage_ok(spec_a, solution, level_index)
                if not ok:
                    raise AssertionError(message)
                if level_index == 3:
                    crucible_disabled_failures_by_level[config.name] += 1

                ok, message = _replay_logic(spec_a, solution)
                if not ok:
                    raise AssertionError(message)
                ok, message = _blocked_actions_preserve_state(spec_a)
                if not ok:
                    raise AssertionError(message)
                ok, message = _visible_objects_meaningful(spec_a, solution)
                if not ok:
                    raise AssertionError(message)

                engine_actions = _engine_actions_for_solution(spec_a, solution)
                if engine_actions is None:
                    raise AssertionError("no keyboard replay path")
                if seed in ENGINE_REPLAY_SEEDS:
                    sampled_engine_replays_checked += 1
                    ok, message = _engine_replay(seed, level_index, engine_actions)
                    if not ok:
                        sampled_engine_replay_failures += 1
                        raise AssertionError(message)
                    engine_bfs_lengths.append(len(solution))
                    engine_keyboard_counts.append(len(engine_actions))

                signatures.add(spec_signature(spec_a))
                topologies_by_level[config.name].add(_topology_signature(spec_a))
                fingerprints_by_level[config.name].add(tuple(plan.index for plan in solution))
                metrics = _metrics(spec_a)
                for key, value in metrics.items():
                    metrics_by_level[config.name][key].append(value)
                solution_lengths[config.name].append(len(solution))
                keyboard_counts[config.name].append(len(engine_actions))
                regulator_activations_by_level[config.name].append(regulator_activations)
                crucible_activations_by_level[config.name].append(crucible_activations)
                lengths_for_seed.append(len(solution))
                if level_index == 0:
                    reset_signatures.add(spec_signature(spec_a))
            except Exception as exc:
                seed_failures += 1
                issues.append(f"seed {seed:02d} {config.name}: {exc}")

        for reset_count in range(1, RESET_SANITY_REPLAYS + 1):
            try:
                reset_spec = generate_spec(seed, 0, reset_count)
                reset_signatures.add(spec_signature(reset_spec))
                specs_tested += 1
                if seed in ENGINE_REPLAY_SEEDS:
                    sampled_reset_replays_checked += 1
                    ok, message, bfs_len, key_count = _reset_replay(seed, reset_count)
                    if not ok:
                        sampled_reset_replay_failures += 1
                        raise AssertionError(message)
                    reset_signature_matches += 1
                    reset_bfs_lengths.append(bfs_len)
                    reset_keyboard_counts.append(key_count)
            except Exception as exc:
                seed_failures += 1
                issues.append(f"seed {seed:02d} reset {reset_count}: {exc}")
        if len(reset_signatures) < 2:
            seed_failures += 1
            issues.append(f"seed {seed:02d}: reset variants did not vary")

        per_seed_lengths[seed] = lengths_for_seed
        length_text = ", ".join(f"L{i + 1}={value}" for i, value in enumerate(lengths_for_seed))
        print(f"Seed {seed:02d}: checks={len(lengths_for_seed)}, failures={seed_failures}")
        print(f"  lengths: {length_text}")

    if len(signatures) < 35:
        issues.append("insufficient unique generated signatures")
    all_topologies = set().union(*topologies_by_level.values()) if topologies_by_level else set()
    if len(all_topologies) < 30:
        issues.append("insufficient topology variation")

    print(f"Generated specs tested: {specs_tested}")
    print(f"Unique signatures: {len(signatures)}")

    print("Variant diversity by level:")
    for config in LEVEL_CONFIGS:
        name = config.name
        metric = metrics_by_level[name]
        print(
            f"  {name}: objects={sorted(set(metric['objects']))}, "
            f"chambers={sorted(set(metric['chambers']))}, molds={sorted(set(metric['molds']))}, "
            f"bellows={sorted(set(metric['bellows']))}, vents={sorted(set(metric['vents']))}, "
            f"equalizers={sorted(set(metric['equalizers']))}, "
            f"regulators={sorted(set(metric['regulators']))}, "
            f"crucibles={sorted(set(metric['crucibles']))}"
        )
        print(
            f"    topologies={len(topologies_by_level[name])}, "
            f"solution_fingerprints={len(fingerprints_by_level[name])}, "
            f"lengths={sorted(set(solution_lengths[name]))}, "
            f"regulator_activations={sorted(set(regulator_activations_by_level[name]))}, "
            f"crucible_activations={sorted(set(crucible_activations_by_level[name]))}"
        )

    all_metrics = defaultdict(list)
    for metric in metrics_by_level.values():
        for key, values in metric.items():
            all_metrics[key].extend(values)

    print("Generator structure summary:")
    print(
        f"  objects={_range(all_metrics['objects'])}, chambers={_range(all_metrics['chambers'])}, "
        f"molds={_range(all_metrics['molds'])}, bbox_area={_range(all_metrics['bbox_area'])}"
    )
    print(
        f"  bellows={_range(all_metrics['bellows'])}, vents={_range(all_metrics['vents'])}, "
        f"equalizers={_range(all_metrics['equalizers'])}, regulators={_range(all_metrics['regulators'])}, "
        f"crucibles={_range(all_metrics['crucibles'])}, targets={_range(all_metrics['target'])}"
    )

    print("BFS solution lengths by level:")
    for name, values in solution_lengths.items():
        print(f"  {name}: min={min(values)} max={max(values)} values={sorted(set(values))}")

    print("Keyboard replay action counts by level:")
    for name, values in keyboard_counts.items():
        print(f"  {name}: min={min(values)} max={max(values)} values={sorted(set(values))}")

    default_ok, default_message, default_lengths, default_keyboard_total = _full_game_replay(0)
    if not default_ok:
        issues.append(f"default seed full replay: {default_message}")

    reset_ok, reset_message, reset_lengths, reset_keyboard_total = _full_game_replay(
        0,
        RESET_SANITY_REPLAYS,
    )
    if not reset_ok:
        issues.append(f"default seed reset full replay: {reset_message}")

    print("Engine completion simulation:")
    print(f"  status={'WIN' if default_ok else 'FAIL'}")
    print(f"  default seed BFS lengths: {default_lengths}")
    print(f"  default seed keyboard actions replayed: {default_keyboard_total}")
    print(f"  sampled engine replays checked: {sampled_engine_replays_checked}")
    print(f"  sampled engine replay failures: {sampled_engine_replay_failures}")

    print(f"Engine completion after {RESET_SANITY_REPLAYS} development resets:")
    print(f"  status={'WIN' if reset_ok else 'FAIL'}")
    print(f"  reset BFS lengths: {reset_lengths}")
    print(f"  reset keyboard actions replayed: {reset_keyboard_total}")
    print(f"  sampled reset replays checked: {sampled_reset_replays_checked}")
    print(f"  sampled reset replay failures: {sampled_reset_replay_failures}")
    print(f"  reset deterministic signature matches={reset_signature_matches}")

    if issues:
        print("Issues:")
        for issue in issues:
            print(f"  - {issue}")
        print("FAIL: Bellows Forge verification found issues")
        return 1

    print("Issues: none")
    print("PASS: Bellows Forge generation, mechanics, BFS plans, resets, and engine replays are valid")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
