"""Start Bellows Forge.

Usage:
    python run.py
    Open http://127.0.0.1:5000
"""

from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parent.parent.parent
HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(HERE))

from bellows_forge import BellowsForge
from ipe.server import run_server


if __name__ == "__main__":
    here = Path(__file__).resolve().parent
    game = BellowsForge(seed=0)
    run_server(game, port=5000, log_dir=str(here / "play_logs"))
