"""
verify.py — Confirm every level is solvable across multiple seeds.

Uses a programmatic solver: for each merged piece in the target, compute the
gray-cell placements that would create it, simulate those clicks, then verify
the board matches the target.

Usage:
    python verify.py
"""

from __future__ import annotations

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent.parent))

from merge_blocks import (
    MergeBlocks,
    BOARD_W, BOARD_H, GAME_X,
    YELLOW, GREEN, RED, ORANGE, BLUE,
)
from ipe import ActionInput, GameAction


def _solution_pieces(target: list[list[int]]) -> list[list[tuple[int, int]]]:
    """Return one group of 4 cells per merged piece (piece-by-piece order).

    Clicking all cells of each piece before moving to the next prevents
    accidental cross-piece merges that would occur with plain row-major order
    when different pieces share the same row or column.
    """
    pieces: list[list[tuple[int, int]]] = []
    for r in range(BOARD_H):
        for c in range(BOARD_W):
            t = target[r][c]
            if t == YELLOW:
                pieces.append([(r, c + dc) for dc in range(4)])
            elif t == GREEN:
                pieces.append([(r + dr, c) for dr in range(-3, 1)])
            elif t == RED:
                pieces.append([(r + dr, c + dc) for dr, dc in [(-1, 0), (-1, 1), (0, 0), (0, 1)]])
            elif t == ORANGE:   # anti-diagonal ↗, result at bottom-left (r, c)
                pieces.append([(r - di, c + di) for di in range(4)])
            elif t == BLUE:     # main diagonal ↘, result at top-left (r, c)
                pieces.append([(r + di, c + di) for di in range(4)])
    return pieces


def _make_click(game: MergeBlocks, row: int, col: int) -> ActionInput:
    """Convert a board (row, col) to a display-coordinate ACTION6."""
    scale, x_off, y_off = game.camera._calculate_scale_and_offset()
    gx = GAME_X + col
    gy = row
    disp_x = gx * scale + x_off + scale // 2
    disp_y = gy * scale + y_off + scale // 2
    return ActionInput(id=GameAction.ACTION6, data={"x": disp_x, "y": disp_y})


def solve_level(game: MergeBlocks, level_idx: int) -> tuple[bool, int]:
    """
    Solve one level programmatically.
    Returns (passed, num_actions).

    Winning a non-final level triggers an automatic level transition inside
    perform_action, resetting the board before we can inspect it. We use the
    score counter instead: a solved level increments game._score by 1.
    """
    game.set_level(level_idx)
    target = game._target
    score_before = game._score

    total_actions = 0
    for cells in _solution_pieces(target):
        for row, col in cells:
            game.perform_action(_make_click(game, row, col))
            total_actions += 1

    passed = game._score > score_before
    return passed, total_actions


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

print("Verifying solvability across 10 seeds …")
print()

all_ok = True
for seed in range(10):
    game = MergeBlocks(seed=seed)
    level_results: list[str] = []
    ok_all = True

    for lvl in range(4):
        passed, n = solve_level(game, lvl)
        level_results.append(f"{n:3d}" if passed else "FAIL")
        if not passed:
            ok_all = False

    status = "OK  " if ok_all else "FAIL"
    print(f"  Seed {seed:2d}: [{status}]  actions per level: {level_results}")
    if not ok_all:
        all_ok = False

print()
if all_ok:
    print("All seeds solvable!")
else:
    print("SOME SEEDS FAILED — fix level generation.")