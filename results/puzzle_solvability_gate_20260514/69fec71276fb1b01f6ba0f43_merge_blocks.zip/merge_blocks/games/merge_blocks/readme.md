# Merge Blocks

**Category:** Orchestration — State Machine (STM)  
**Difficulty levers used:** Action Coupling · Hidden Constraints · Non-Commutativity · Irreversible Actions

## How to play

The screen is split in two:
- **Left panel** — the reference (target) configuration you must reach.
- **Right panel** — the interactive game board.

Click any **empty cell** on the right panel to place a **gray square**.  
Click a **gray square** to remove it.  
Merged pieces (yellow / green / red / orange / blue) are **permanent** and cannot be removed.

### Merge rules (discovered through play — no hints given)

| Pattern | Result |
|---------|--------|
| Exactly 4 gray in a horizontal row | All disappear; the **leftmost** becomes **yellow** |
| Exactly 4 gray in a vertical column | All disappear; the **bottommost** becomes **green** |
| 4 gray in a 2 × 2 block | All disappear; the **bottom-left** becomes **red** |
| Exactly 4 gray on an anti-diagonal ↗ | All disappear; the **bottom-left** becomes **orange** |
| Exactly 4 gray on a main diagonal ↘ | All disappear; the **top-left** becomes **blue** |

Match the reference panel to complete the level.

## Controls

| Action | Mouse | Keyboard |
|--------|-------|----------|
| Place / remove | Click cell | WASD to move cursor, Space to toggle |
| Restart level | — | R |

## Levels

| # | Name | Target pieces |
|---|------|--------------|
| 1 | Easy | 15 yellow + 12 green |
| 2 | Medium | 14 yellow + 12 green + 5 red |
| 3 | Hard | 13 yellow + 5 orange + 10 green + 5 red |
| 4 | Very Hard | 12 yellow + 5 orange + 4 blue + 10 green + 5 red |

## Running

```bash
# from the for_contributors/ root
cd games/merge_blocks
python run.py
# open http://127.0.0.1:5000
```

## Verification

```bash
python verify.py
```