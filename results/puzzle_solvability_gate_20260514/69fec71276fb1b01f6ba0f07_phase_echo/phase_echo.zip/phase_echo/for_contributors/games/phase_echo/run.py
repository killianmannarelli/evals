import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent.parent))

from phase_echo import PhaseEcho
from ipe.server import run_server

if __name__ == "__main__":
    _here = Path(__file__).resolve().parent
    game = PhaseEcho(seed=0)
    run_server(game, port=5000, log_dir=str(_here / "play_logs"))
