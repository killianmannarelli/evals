from __future__ import annotations

import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
sys.path.append(str(ROOT))

from ipe.enums import ActionInput, GameAction, GameState
from games.phase_echo.phase_echo import PhaseEcho


# 1 = Up/W, 2 = Down/S, 3 = Left/A, 4 = Right/D, 5 = Wait/Space
SOLUTIONS = {
    "L1 Easy": [
        1, 1, 1, 4, 4, 1, 4, 1, 4
    ],

    "L2 Medium": [
        2, 2, 4, 4, 1, 1, 1, 1, 1, 5
    ],

    "L3 Hard": [
        3, 3, 3, 3,
        1, 1, 1, 1,
        3, 3,
        1, 1, 1, 1,
        4, 2, 4, 4, 1, 4, 4
    ],

    "L4 Very Hard": [
        1, 4, 2, 4, 1, 4, 4, 4, 4
    ],
}


def make_action(action_id: int) -> ActionInput:
    return ActionInput(id=GameAction.from_id(action_id))


def try_solution(level_idx: int, moves: list[int], generation: int) -> tuple[bool, PhaseEcho]:
    game = PhaseEcho(seed=12345)

    # Match randomized reset variants.
    if hasattr(game, "_generation"):
        game._generation = generation

    game.set_level(level_idx)

    before_level = game.level_index

    for move in moves:
        game.perform_action(make_action(move))

        if game.state == GameState.GAME_OVER:
            return False, game

    completed = (
        game.level_index > before_level
        or game.state == GameState.WIN
    )

    return completed, game


def verify_level(level_idx: int, level_name: str, moves: list[int]) -> None:
    print()
    print(f"Checking {level_name}...")
    print(f"Moves: {moves}")

    for generation in range(0, 100):
        completed, game = try_solution(level_idx, moves, generation)

        if completed:
            print(f"PASS: {level_name} completed")
            print(f"Matching generation: {generation}")
            print(f"Current level index: {game.level_index}")
            print(f"Current state: {game.state}")
            return

    raise RuntimeError(
        f"FAIL: {level_name} did not complete for generations 0..99.\n"
        f"Moves used: {moves}\n"
        f"This means the hardcoded move list does not match the current code/layout."
    )


def main():
    for level_idx, (level_name, moves) in enumerate(SOLUTIONS.items()):
        verify_level(level_idx, level_name, moves)

    print()
    print("===================================")
    print("ALL LEVELS PASS")
    print("===================================")


if __name__ == "__main__":
    main()