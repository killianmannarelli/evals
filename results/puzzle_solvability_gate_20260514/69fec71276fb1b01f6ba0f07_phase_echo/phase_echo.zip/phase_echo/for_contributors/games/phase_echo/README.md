# Phase Echo

Phase Echo is a discovery-based pursuit and evasion puzzle game built around hidden environmental rules and deterministic enemy movement.

The player controls a single avatar on a grid and must reach the exit. However, the environment constantly changes depending on enemy positions and timing. The game does not explain its mechanics directly — the player is expected to learn the rules through observation, experimentation, and repeated interaction.

The puzzle focuses on:
- temporal planning,
- hidden rule inference,
- action ordering,
- and dynamic terrain behavior.

---

# Core Idea

Some tiles in the environment behave differently depending on nearby enemy activity.

As enemies move, they temporarily alter the map:
- certain tiles become blocked,
- bridges appear or disappear,
- and unstable terrain can permanently collapse.

The exit only becomes usable when enough phase tiles are activated simultaneously.

Because enemy movement is deterministic, the puzzle becomes a timing and prediction problem rather than a reflex-based game.

---

# Gameplay Features

- 4 difficulty levels
- deterministic enemy movement
- hidden rule interactions
- randomized reset states for infinite playthroughs
- keyboard-only support
- mouse-click movement support
- fully visual gameplay with no language dependency

---

# Difficulty Levers Used

The game intentionally combines multiple difficulty mechanisms:

- Action Coupling
- Non-Commutativity
- Hidden Constraints
- Transformation Chains
- Irreversible Actions
- Time-Locked Objects

---

# Controls

## Keyboard Controls

| Key | Action |
|---|---|
| W / Up Arrow | Move Up |
| S / Down Arrow | Move Down |
| A / Left Arrow | Move Left |
| D / Right Arrow | Move Right |
| Space | Wait |

## Mouse Controls

- Click an adjacent tile to move toward it.
- Clicking elsewhere performs a wait action.

---

# Visual Elements

| Visual | Meaning |
|---|---|
| Dark red square | Player |
| Black square with pink cross | Pulse enemy |
| Pink outlined tiles | Phase tiles |
| Grey tile | Exit |
| Grey/blue bridge tiles | Dynamic bridge system |
| Dark unstable tiles | Collapse terrain |

---

# Hidden Rule System

The game does not explicitly explain its mechanics during play.

Players are expected to infer:
- how enemy proximity changes terrain,
- when bridges activate,
- how timing affects movement,
- and how phase interactions unlock the exit.

Immediate visual feedback after every move allows the rules to be learned naturally.

---

# Reset Behavior

Resetting a level generates a new randomized starting configuration while preserving the same underlying rule structure. This allows effectively infinite playthrough variations.

The randomness is deterministic and seed-based to ensure replay consistency and verifier compatibility.

---

# Verification

Run locally:

```bash
python verify.py