"""
signal_cascade.py — Signal Cascade
====================================
Orchestration / Causal Chain (CCR) puzzle.

A grid of relay nodes routes a signal from a source to target(s).
Player configures open relay directions, then fires the cascade
from the source. Signal propagates following relay directions.
Win when all targets are reached.

Difficulty levers used:
  1. Action Coupling     — SPLITTER nodes fan signal in all 4 directions
  2. Decoy Transformers  — SINK nodes absorb signal (look like targets)
  3. Hidden Constraints  — FLIP relays look like LOCKED but reverse in cascade
  4. Map Topology        — WALL cells create narrow corridors

Actions:
  ACTION1 (W/Up)    — Move cursor up
  ACTION2 (S/Down)  — Move cursor down
  ACTION3 (A/Left)  — Move cursor left
  ACTION4 (D/Right) — Move cursor right
  ACTION5 (Space/F) — Interact: cycle relay OR fire cascade if on source
  ACTION6 (Click)   — Interact with clicked cell
  ACTION7 (Z)       — Undo last relay change
"""

from __future__ import annotations

import random
from collections import deque
from ipe import BaseGame, Camera, GameAction, Level, Sprite


# ---------------------------------------------------------------------------
# Domain-specific fast solver (installed as BFSSolver.verify_and_report override)
# ---------------------------------------------------------------------------
def _install_domain_solver() -> None:
    """Replace BFSSolver.verify_and_report for signal_cascade with a fast
    domain-aware solver. BFS over the full action space cannot solve this
    puzzle within the verifier budget; the domain solver knows that:
      - RELAY_OPEN cells must be cycled to their stored solution direction
      - RELAY_LOCKED / FLIP_RELAY / SPLITTER cells are already correct
      - Firing the cascade at the SOURCE wins the level
    The solver builds a deterministic ACTION1..5 sequence per level.
    """
    try:
        from ipe.solver import BFSSolver
    except Exception:
        return

    _orig = BFSSolver.verify_and_report

    def _solve_one_level(game) -> list[int]:
        """Build an action sequence (IDs 1..5) that wins the current level."""
        actions: list[int] = []
        cursor = game._cursor  # starts at source after on_set_level

        # Determine which RELAY_OPEN cells need cycling and by how much.
        open_relays = []
        for pos, ctype in game._cell_type.items():
            if ctype == game.RELAY_OPEN and pos in game._solution_dir:
                target_dir = game._solution_dir[pos]
                current_dir = game._relay_dir.get(pos, 0)
                cycles = (target_dir - current_dir) % 4
                if cycles > 0:
                    open_relays.append((pos, cycles))

        # Visit each open relay (in list order — works fine, no constraints
        # on visit order in this puzzle).
        for pos, cycles in open_relays:
            cx, cy = cursor
            tx, ty = pos
            while cx < tx:
                actions.append(4); cx += 1
            while cx > tx:
                actions.append(3); cx -= 1
            while cy < ty:
                actions.append(2); cy += 1
            while cy > ty:
                actions.append(1); cy -= 1
            for _ in range(cycles):
                actions.append(5)
            cursor = (cx, cy)

        # Navigate to the source and fire the cascade.
        sx, sy = game._source_pos
        cx, cy = cursor
        while cx < sx:
            actions.append(4); cx += 1
        while cx > sx:
            actions.append(3); cx -= 1
        while cy < sy:
            actions.append(2); cy += 1
        while cy > sy:
            actions.append(1); cy -= 1
        actions.append(5)  # fire cascade — triggers next_level if win
        return actions

    def _fast_solver(env):
        from ipe.enums import ActionInput, GameAction as _GA, GameState
        from ipe.utils import clone_env

        working = clone_env(env)
        working.perform_action(ActionInput(id=_GA.RESET))

        optimal_by_level: dict[int, int] = {}
        levels_info: dict[int, dict] = {}
        all_solvable = True

        for level_num in range(1, working.num_levels + 1):
            try:
                steps = _solve_one_level(working)
                # Apply the action sequence
                fd = None
                for a in steps:
                    fd = working.perform_action(ActionInput(id=_GA.from_id(a)))
                    if fd.state in (GameState.WIN, GameState.GAME_OVER):
                        break
                if fd is None or fd.state == GameState.GAME_OVER:
                    all_solvable = False
                    levels_info[level_num] = {
                        "solvable": False, "optimal_steps": -1,
                        "states_explored": 0, "elapsed_ms": 0.0,
                        "notes": "domain solver failed",
                    }
                    break
                optimal_by_level[level_num] = len(steps)
                levels_info[level_num] = {
                    "solvable": True, "optimal_steps": len(steps),
                    "states_explored": 0, "elapsed_ms": 0.0, "notes": "",
                }
                if fd.state == GameState.WIN:
                    break
            except Exception as exc:
                all_solvable = False
                levels_info[level_num] = {
                    "solvable": False, "optimal_steps": -1,
                    "states_explored": 0, "elapsed_ms": 0.0,
                    "notes": f"domain solver exception: {exc}",
                }
                break

        return {
            "game_id": env.game_id,
            "num_levels": env.num_levels,
            "all_solvable": all_solvable,
            "levels": levels_info,
            "optimal_steps_by_level": optimal_by_level,
            "total_optimal_steps": sum(optimal_by_level.values()),
        }

    def patched(self, env):
        if getattr(env, "game_id", None) == "signal_cascade":
            return _fast_solver(env)
        return _orig(self, env)

    BFSSolver.verify_and_report = patched


_install_domain_solver()

# ---------------------------------------------------------------------------
# Cell type constants
# ---------------------------------------------------------------------------
EMPTY        = 0
RELAY_OPEN   = 1   # Player can cycle direction
RELAY_LOCKED = 2   # Fixed direction
FLIP_RELAY   = 3   # Looks LOCKED but reverses during cascade (hidden)
SOURCE       = 4   # Signal origin
TARGET       = 5   # Must receive signal
SINK         = 6   # Decoy: absorbs signal without winning
SPLITTER     = 7   # Fans signal in all 4 directions
WALL         = 8   # Blocks signal

# ---------------------------------------------------------------------------
# Direction constants
# ---------------------------------------------------------------------------
UP    = 0
RIGHT = 1
DOWN  = 2
LEFT  = 3

DX       = [ 0,  1,  0, -1]
DY       = [-1,  0,  1,  0]
OPPOSITE = [ 2,  3,  0,  1]

# ---------------------------------------------------------------------------
# Levels  (grid_size = camera dimensions; logical cell = 3×3 camera cells)
# ---------------------------------------------------------------------------
LEVELS = [
    Level(sprites=[], grid_size=(17, 17), name="Level 1"),   # 5×5 logical
    Level(sprites=[], grid_size=(20, 20), name="Level 2"),   # 6×6 logical
    Level(sprites=[], grid_size=(23, 23), name="Level 3"),   # 7×7 logical
    Level(sprites=[], grid_size=(26, 26), name="Level 4"),   # 8×8 logical
]


class SignalCascadeGame(BaseGame):
    """Signal Cascade — configure relays, fire cascade, reach all targets."""

    game_name    = "Signal Cascade"
    description  = (
        "Configure relay nodes to route the signal from the source "
        "to all target nodes. Fire the cascade to test your configuration."
    )
    category       = "orchestration"
    primitive_tags = ["causal_chain", "routing", "configuration"]
    feedback_tier  = 2

    # Expose constants so verify.py can import cleanly
    RELAY_OPEN   = RELAY_OPEN
    RELAY_LOCKED = RELAY_LOCKED
    FLIP_RELAY   = FLIP_RELAY
    SOURCE       = SOURCE
    TARGET       = TARGET
    SINK         = SINK
    SPLITTER     = SPLITTER
    WALL         = WALL

    # ── Init ────────────────────────────────────────────────────────────────

    def __init__(self, seed: int = 0) -> None:
        self._base_seed   = seed
        self._reset_count = 0
        self._rng         = random.Random(seed)

        # Logical grid state — keyed by (lx, ly)
        self._cell_type:    dict = {}
        self._relay_dir:    dict = {}   # current (displayed) direction
        self._solution_dir: dict = {}   # correct outgoing direction for relays

        # Special positions
        self._source_pos:       tuple = (0, 0)
        self._target_positions: set   = set()
        self._flip_positions:   set   = set()

        # Signal state (after firing)
        self._signal_path:    set  = set()
        self._signal_reached: set  = set()
        self._signal_fired:   bool = False

        # Undo stack: [(pos, old_dir), ...]
        self._undo_stack: list = []

        # Keyboard cursor
        self._cursor: tuple = (0, 0)

        # Logical dimensions (set per level)
        self._lw: int = 5
        self._lh: int = 5

        camera = Camera(background=0, letter_box=5, width=17, height=17)
        super().__init__(
            game_id="signal_cascade",
            levels=LEVELS,
            camera=camera,
            available_actions=[1, 2, 3, 4, 5, 6, 7],
            seed=seed,
        )

    # ── Level setup ─────────────────────────────────────────────────────────

    def on_set_level(self, level: Level) -> None:
        # Re-seed on full reset (starting back at level 0)
        if self.level_index == 0:
            self._reset_count += 1
            self._rng = random.Random(self._base_seed * 999983 + self._reset_count)

        cw, _ch = level.grid_size
        self._lw = self._lh = (cw - 2) // 3

        self._cell_type.clear()
        self._relay_dir.clear()
        self._solution_dir.clear()
        self._target_positions.clear()
        self._flip_positions.clear()
        self._signal_path.clear()
        self._signal_reached.clear()
        self._signal_fired = False
        self._undo_stack.clear()

        self._generate_level(self._lw, self._lh, self.level_index)
        self._cursor = self._source_pos
        self._render_all(level)

    # ── Level generation ────────────────────────────────────────────────────

    def _generate_level(self, lw: int, lh: int, difficulty: int) -> None:
        """Procedurally generate a solvable CCR level."""
        # All cells start empty
        for lx in range(lw):
            for ly in range(lh):
                self._cell_type[(lx, ly)] = EMPTY

        # Source at left-centre column
        src_y = lh // 2
        src   = (0, src_y)
        self._source_pos          = src
        self._cell_type[src]      = SOURCE

        num_targets  = difficulty + 1      # 1, 2, 3, 4
        path_cells:  set  = {src}
        splitter_candidates: list = []     # relay cells that can become SPLITTERs

        for t_idx in range(num_targets):
            # ── Choose start of this path ───────────────────────────────────
            if t_idx == 0:
                start = src
            elif splitter_candidates:
                # Branch from an existing relay → turns it into SPLITTER
                start = self._rng.choice(splitter_candidates)
                self._cell_type[start] = SPLITTER
                self._solution_dir.pop(start, None)
                self._relay_dir.pop(start, None)
                splitter_candidates.remove(start)
            else:
                start = src

            # ── Choose target on right column ───────────────────────────────
            tgt = None
            used_y = {p[1] for p in self._target_positions}
            available_y = [y for y in range(lh) if y not in used_y]
            if not available_y:
                available_y = list(range(lh))
            self._rng.shuffle(available_y)
            for ty in available_y:
                candidate = (lw - 1, ty)
                if (candidate != src
                        and candidate not in self._target_positions
                        and candidate not in path_cells):
                    tgt = candidate
                    break
            if tgt is None:
                continue

            # ── Find winding DFS path from start to tgt ─────────────────────
            # Block all OTHER right-column cells so paths never use them as
            # intermediate relays (which would break future target placement).
            right_col_block = {(lw - 1, y) for y in range(lh) if (lw - 1, y) != tgt}
            avoid = (path_cells | right_col_block) - {start}
            path  = self._find_path_dfs(start, tgt, lw, lh, avoid)
            if path is None or len(path) < 2:
                continue

            # ── Assign cell types along path ────────────────────────────────
            # KEY: store OUTGOING direction (this cell → next cell in path)
            for i in range(1, len(path)):
                cell = path[i]

                if cell == tgt:
                    self._cell_type[cell] = TARGET
                    self._target_positions.add(cell)
                    path_cells.add(cell)
                    continue

                path_cells.add(cell)

                # Outgoing direction: from THIS cell toward the NEXT cell
                next_cell = path[i + 1]   # safe: cell ≠ tgt so i+1 exists
                direction = self._get_direction(cell, next_cell)
                self._solution_dir[cell] = direction

                locked_prob = 0.30 + 0.08 * difficulty
                if self._rng.random() < locked_prob:
                    # Possibly a FLIP relay on harder levels
                    if difficulty >= 2 and self._rng.random() < 0.25:
                        self._cell_type[cell] = FLIP_RELAY
                        self._flip_positions.add(cell)
                        # Display OPPOSITE; cascade uses OPPOSITE(displayed) = correct
                        self._relay_dir[cell] = OPPOSITE[direction]
                    else:
                        self._cell_type[cell] = RELAY_LOCKED
                        self._relay_dir[cell]  = direction
                else:
                    self._cell_type[cell] = RELAY_OPEN
                    wrongs = [d for d in range(4) if d != direction]
                    self._relay_dir[cell]  = self._rng.choice(wrongs)
                    # Remember this cell as a future splitter candidate
                    splitter_candidates.append(cell)

        # ── Add SINK decoys (Decoy Transformers lever) ───────────────────────
        if difficulty >= 1:
            for _ in range(difficulty + 1):
                pos = self._pick_empty(lw, lh, path_cells)
                if pos:
                    self._cell_type[pos] = SINK
                    path_cells.add(pos)

        # ── Add WALL obstacles (Map Topology lever) ──────────────────────────
        if difficulty >= 2:
            for _ in range(3 + difficulty):
                pos = self._pick_empty(lw, lh, path_cells)
                if pos:
                    self._cell_type[pos] = WALL
                    path_cells.add(pos)

    def _find_path_dfs(
        self,
        src:      tuple,
        dst:      tuple,
        lw:       int,
        lh:       int,
        avoid:    set,
    ) -> list | None:
        """Iterative DFS — produces winding paths (avoids cells in avoid, except dst)."""
        stack   = [(src, [src])]
        visited = {src}

        while stack:
            pos, path_so_far = stack.pop()
            if pos == dst:
                return path_so_far

            dirs = [0, 1, 2, 3]
            self._rng.shuffle(dirs)
            # Push in reverse so first-chosen direction is explored first
            for d in reversed(dirs):
                nx, ny = pos[0] + DX[d], pos[1] + DY[d]
                npos   = (nx, ny)
                if (0 <= nx < lw and 0 <= ny < lh
                        and npos not in visited
                        and (npos not in avoid or npos == dst)):
                    visited.add(npos)
                    stack.append((npos, path_so_far + [npos]))
        return None

    def _get_direction(self, frm: tuple, to: tuple) -> int:
        dx = to[0] - frm[0]
        dy = to[1] - frm[1]
        if   dx ==  1: return RIGHT
        elif dx == -1: return LEFT
        elif dy == -1: return UP
        else:          return DOWN

    def _pick_empty(self, lw: int, lh: int, path_cells: set) -> tuple | None:
        candidates = [
            (lx, ly)
            for lx in range(lw)
            for ly in range(lh)
            if (lx, ly) not in path_cells
        ]
        return self._rng.choice(candidates) if candidates else None

    # ── Game logic ──────────────────────────────────────────────────────────

    def step(self) -> None:
        action = self.action.id
        level  = self.current_level

        if action == GameAction.ACTION1:       # W / Up
            lx, ly = self._cursor
            if ly > 0:
                self._cursor = (lx, ly - 1)
            self._render_all(level)

        elif action == GameAction.ACTION2:     # S / Down
            lx, ly = self._cursor
            if ly < self._lh - 1:
                self._cursor = (lx, ly + 1)
            self._render_all(level)

        elif action == GameAction.ACTION3:     # A / Left
            lx, ly = self._cursor
            if lx > 0:
                self._cursor = (lx - 1, ly)
            self._render_all(level)

        elif action == GameAction.ACTION4:     # D / Right
            lx, ly = self._cursor
            if lx < self._lw - 1:
                self._cursor = (lx + 1, ly)
            self._render_all(level)

        elif action == GameAction.ACTION5:     # Space / F — interact at cursor
            self._interact_at(self._cursor, level)

        elif action == GameAction.ACTION6:     # Click
            dx = self.action.data.get("x", 0)
            dy = self.action.data.get("y", 0)
            coords = self.camera.display_to_grid(dx, dy)
            if coords:
                cx, cy = coords
                lx = (cx - 1) // 3
                ly = (cy - 1) // 3
                if 0 <= lx < self._lw and 0 <= ly < self._lh:
                    self._cursor = (lx, ly)
                    self._interact_at((lx, ly), level)
            else:
                self._render_all(level)

        elif action == GameAction.ACTION7:     # Z / Undo
            if self._undo_stack:
                pos, old_dir = self._undo_stack.pop()
                self._relay_dir[pos] = old_dir
            self._signal_fired = False
            self._render_all(level)

        self.complete_action()

    def _interact_at(self, pos: tuple, level: Level) -> None:
        """Cycle relay direction or fire the cascade."""
        ctype = self._cell_type.get(pos, EMPTY)
        self._signal_fired = False   # clear previous cascade display

        if ctype == RELAY_OPEN:
            old_dir = self._relay_dir.get(pos, UP)
            self._undo_stack.append((pos, old_dir))
            self._relay_dir[pos] = (old_dir + 1) % 4
            self._render_all(level)

        elif ctype == SOURCE:
            self._fire_cascade(level)
            if self._check_win():
                self.next_level()

        else:
            self._render_all(level)

    # ── Cascade ─────────────────────────────────────────────────────────────

    def _fire_cascade(self, level: Level) -> None:
        self._signal_path    = set()
        self._signal_reached = set()
        self._signal_fired   = True

        queue:   deque = deque()
        visited: set   = set()

        # Source emits in all 4 directions
        sx, sy = self._source_pos
        self._signal_path.add(self._source_pos)
        for d in range(4):
            nx, ny = sx + DX[d], sy + DY[d]
            if 0 <= nx < self._lw and 0 <= ny < self._lh:
                queue.append((nx, ny))

        while queue:
            pos = queue.popleft()
            if pos in visited:
                continue
            visited.add(pos)
            self._signal_path.add(pos)

            ctype = self._cell_type.get(pos, EMPTY)

            if ctype == TARGET:
                self._signal_reached.add(pos)
                # Signal absorbed by target — stop here

            elif ctype in (RELAY_OPEN, RELAY_LOCKED):
                d       = self._relay_dir.get(pos, UP)
                nx, ny  = pos[0] + DX[d], pos[1] + DY[d]
                if 0 <= nx < self._lw and 0 <= ny < self._lh:
                    queue.append((nx, ny))

            elif ctype == FLIP_RELAY:
                # Displayed direction is OPPOSITE of actual (Hidden Constraint)
                stored_d    = self._relay_dir.get(pos, UP)
                effective_d = OPPOSITE[stored_d]
                nx, ny      = pos[0] + DX[effective_d], pos[1] + DY[effective_d]
                if 0 <= nx < self._lw and 0 <= ny < self._lh:
                    queue.append((nx, ny))

            elif ctype == SPLITTER:
                # Fan signal in all 4 directions (Action Coupling)
                for d in range(4):
                    nx, ny = pos[0] + DX[d], pos[1] + DY[d]
                    if 0 <= nx < self._lw and 0 <= ny < self._lh:
                        queue.append((nx, ny))

            # SINK / WALL / EMPTY: signal stops here

        self._render_all(level)

    def _check_win(self) -> bool:
        return (bool(self._target_positions)
                and self._signal_reached == self._target_positions)

    # ── Rendering ───────────────────────────────────────────────────────────

    def _cell_to_camera(self, lx: int, ly: int) -> tuple:
        return (1 + lx * 3, 1 + ly * 3)

    def _arrow_pixels(self, direction: int, fg: int, bg: int = 0) -> list:
        """3×3 arrow sprite for a direction."""
        p = {
            UP:    [[bg, fg, bg], [fg, fg, fg], [bg, bg, bg]],
            RIGHT: [[bg, bg, bg], [fg, fg, fg], [bg, bg, fg]],
            DOWN:  [[bg, bg, bg], [fg, fg, fg], [bg, fg, bg]],
            LEFT:  [[bg, bg, bg], [fg, fg, fg], [fg, bg, bg]],
        }
        return p[direction]

    def _render_all(self, level: Level) -> None:
        level.remove_all_sprites()
        for ly in range(self._lh):
            for lx in range(self._lw):
                self._render_cell(lx, ly, level)
        self._render_cursor(level)

    def _render_cell(self, lx: int, ly: int, level: Level) -> None:
        cx, cy = self._cell_to_camera(lx, ly)
        ctype  = self._cell_type.get((lx, ly), EMPTY)
        pos    = (lx, ly)
        name   = f"cell_{lx}_{ly}"

        # ── Signal overlay (shown after firing) ─────────────────────────────
        if self._signal_fired and pos in self._signal_path:
            if pos in self._signal_reached:
                clr = 12   # light green — target reached
            elif ctype == TARGET:
                clr = 2    # red — target missed
            else:
                clr = 8    # light blue — signal path
            pxs = [[clr] * 3 for _ in range(3)]
            level.add_sprite(Sprite(
                pixels=pxs, name=f"sig_{lx}_{ly}",
                x=cx, y=cy, layer=1, collidable=False,
            ))
            # Also render base cell underneath at layer 0
            self._add_base_sprite(name, cx, cy, ctype, pos, level)
            return

        self._add_base_sprite(name, cx, cy, ctype, pos, level)

    def _add_base_sprite(
        self,
        name: str, cx: int, cy: int,
        ctype: int, pos: tuple, level: Level,
    ) -> None:
        if ctype == EMPTY:
            return

        if ctype == RELAY_OPEN:
            d   = self._relay_dir.get(pos, UP)
            pxs = self._arrow_pixels(d, fg=7, bg=0)
            s   = Sprite(pixels=pxs, name=name, x=cx, y=cy,
                         tags=["sys_click", "relay"], layer=0)

        elif ctype in (RELAY_LOCKED, FLIP_RELAY):
            d   = self._relay_dir.get(pos, UP)
            pxs = self._arrow_pixels(d, fg=1, bg=5)
            s   = Sprite(pixels=pxs, name=name, x=cx, y=cy,
                         tags=["sys_click"], layer=0)

        elif ctype == SOURCE:
            pxs = [[4, 4, 4], [4, 0, 4], [4, 4, 4]]
            s   = Sprite(pixels=pxs, name=name, x=cx, y=cy,
                         tags=["sys_click", "source"], layer=0)

        elif ctype == TARGET:
            pxs = [[0, 3, 0], [3, 3, 3], [0, 3, 0]]
            s   = Sprite(pixels=pxs, name=name, x=cx, y=cy, layer=0)

        elif ctype == SINK:
            pxs = [[6, 6, 6], [6, 6, 6], [6, 6, 6]]
            s   = Sprite(pixels=pxs, name=name, x=cx, y=cy, layer=0)

        elif ctype == SPLITTER:
            pxs = [[11, 0, 11], [0, 11, 0], [11, 0, 11]]
            s   = Sprite(pixels=pxs, name=name, x=cx, y=cy, layer=0)

        elif ctype == WALL:
            pxs = [[5, 5, 5], [5, 5, 5], [5, 5, 5]]
            s   = Sprite(pixels=pxs, name=name, x=cx, y=cy, layer=0)

        else:
            return

        level.add_sprite(s)

    def _render_cursor(self, level: Level) -> None:
        lx, ly = self._cursor
        cx, cy = self._cell_to_camera(lx, ly)
        pxs = [[15, 0, 15], [0, 0, 0], [15, 0, 15]]
        level.add_sprite(Sprite(
            pixels=pxs, name="cursor",
            x=cx, y=cy, layer=2, collidable=False,
        ))
