# Signal Cascade

**Category:** Orchestration  
**Style:** Causal Chain (CCR)

## Game Description

A grid of relay nodes connects a signal **Source** to one or more **Targets**.

Your job: configure the open relay nodes to route the signal correctly, then fire the cascade from the Source. Watch the signal propagate — if all Targets light up, you win!

## Cell Types (discovered through play)

- **Yellow hollow square** — Source: click/Space here to fire the cascade
- **Green cross** — Target: signal must reach all of these
- **Orange arrow** — Open relay: click to cycle direction (UP→RIGHT→DOWN→LEFT)
- **Blue arrow on gray** — Locked relay: direction is fixed
- **Magenta solid** — Sink: absorbs signal (does not count as a win)
- **Teal X pattern** — Splitter: fans signal in all 4 directions
- **Gray solid** — Wall: blocks signal

## Controls

| Key | Action |
|-----|--------|
| W/↑ | Move cursor up |
| S/↓ | Move cursor down |
| A/← | Move cursor left |
| D/→ | Move cursor right |
| Space / F | Interact (cycle relay OR fire cascade on Source) |
| Click | Interact with clicked cell |
| Z | Undo last relay change |
| R | Reset level |

## Difficulty Levers Used

1. **Action Coupling** — Splitter nodes fan signal in all 4 directions simultaneously
2. **Decoy Transformers** — Sink nodes absorb signal without counting as a win
3. **Hidden Constraints** — Some locked-looking relays secretly reverse during cascade
4. **Map Topology** — Wall cells create narrow corridors with limited routing paths

## Levels

| Level | Grid | Difficulty |
|-------|------|------------|
| 1 | 5×5 | Easy — single path, one target |
| 2 | 6×6 | Medium — splitter, two targets, sinks |
| 3 | 7×7 | Hard — flip relays, three targets, walls |
| 4 | 8×8 | Very Hard — multiple flips, four targets, complex topology |
