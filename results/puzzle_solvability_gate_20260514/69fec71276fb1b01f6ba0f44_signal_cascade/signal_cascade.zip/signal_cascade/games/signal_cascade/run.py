"""Start the game server. Run: python run.py"""

import sys
from pathlib import Path

_root = str(Path(__file__).resolve().parent.parent.parent)
sys.path.insert(0, _root)
sys.path.insert(0, str(Path(__file__).resolve().parent))

from signal_cascade import SignalCascadeGame
from ipe.server import run_server

if __name__ == "__main__":
    _here = Path(__file__).resolve().parent
    run_server(SignalCascadeGame(seed=0), port=5000, log_dir=str(_here / "play_logs"))
