"""Verify solvability. Run: python verify.py"""

import sys
from pathlib import Path

_root = str(Path(__file__).resolve().parent.parent.parent)
sys.path.insert(0, _root)
sys.path.insert(0, str(Path(__file__).resolve().parent))

from signal_cascade import SignalCascadeGame, RELAY_OPEN

print("Signal Cascade — Solvability Verification")
print("Testing 10 seeds × 4 levels...")
print()

all_ok = True

for seed in range(10):
    g = SignalCascadeGame(seed=seed)

    results = []
    for level_idx in range(g.num_levels):
        g.set_level(level_idx)

        # Set all open relays to their solution directions
        for pos, ctype in g._cell_type.items():
            if ctype == RELAY_OPEN and pos in g._solution_dir:
                g._relay_dir[pos] = g._solution_dir[pos]

        # Fire the cascade
        g._fire_cascade(g.current_level)

        ok = g._check_win()
        results.append("OK  " if ok else "FAIL")
        if not ok:
            all_ok = False
            # Debug info
            print(f"    Seed {seed} Level {level_idx+1}: targets={g._target_positions} "
                  f"reached={g._signal_reached}")

    print(f"  Seed {seed:2d}: {' | '.join(results)}")

print()
if all_ok:
    print("All seeds solvable!")
else:
    print("SOME SEEDS FAILED — fix level generation.")
