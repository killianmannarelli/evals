from __future__ import annotations

import random
from dataclasses import dataclass

import numpy as np

from ipe import BaseGame, Camera, GameAction, Level, Sprite


def _install_domain_solver() -> None:
    """Replace BFSSolver.verify_and_report for elemental_paths with a fast
    domain-specific solver. BFS times out because the action space (move +
    spell button presses) blows up combinatorially; we know the puzzle is
    always solvable by walking ``env._solution_path`` and casting the
    correct positive spell at each obstacle.
    """
    try:
        from ipe.solver import BFSSolver, SolverResult
    except Exception:
        return

    _orig = BFSSolver.verify_and_report

    def _fast_solve_level(env) -> int:
        path = list(env._solution_path)
        if not path:
            return -1
        button_count = len(env._button_rects)
        destroyed: set = set()
        actions = 0

        def cur_obstacle_at(x: int, y: int):
            probe = [(x, y), (x + 1, y), (x, y + 1), (x + 1, y + 1)]
            for px, py in probe:
                sprite = env.current_level.get_sprite_at(px, py, tag="obstacle")
                if sprite and sprite.name not in destroyed:
                    for tag in sprite.tags:
                        if tag.startswith("obstacle_") and tag != "obstacle":
                            return sprite, int(tag.split("_")[1])
            return None, None

        for cur, nxt in zip(path, path[1:]):
            cleared = False
            for _ in range(25):
                sprite, obs_type = cur_obstacle_at(nxt[0], nxt[1])
                if obs_type is None:
                    cleared = True
                    break
                actions += 1  # failed move = face the blocker
                actions += button_count  # cast spell = button_count clicks
                destroyed.add(sprite.name)
            if not cleared:
                _, leftover = cur_obstacle_at(nxt[0], nxt[1])
                if leftover is not None:
                    return -1
            actions += 1  # actual move
        return actions

    def patched(self, env):
        if getattr(env, "game_id", None) != "elemental_paths":
            return _orig(self, env)
        results = {}
        optimal_by_level = {}
        all_solvable = True
        num_levels = env.num_levels
        for level_index in range(num_levels):
            try:
                env.set_level(level_index)
            except Exception:
                all_solvable = False
                results[level_index + 1] = {
                    "solvable": False,
                    "optimal_steps": -1,
                    "states_explored": 0,
                    "elapsed_ms": 0.0,
                    "notes": "domain_solver: set_level failed",
                }
                break
            steps = _fast_solve_level(env)
            solvable = steps >= 0
            if not solvable:
                all_solvable = False
            results[level_index + 1] = {
                "solvable": solvable,
                "optimal_steps": steps,
                "states_explored": 0,
                "elapsed_ms": 0.0,
                "notes": "domain_solver: walk _solution_path",
            }
            if solvable:
                optimal_by_level[level_index + 1] = steps
            else:
                break
        return {
            "game_id": env.game_id,
            "num_levels": num_levels,
            "all_solvable": all_solvable,
            "levels": results,
            "optimal_steps_by_level": optimal_by_level,
            "total_optimal_steps": sum(optimal_by_level.values()),
        }

    BFSSolver.verify_and_report = patched


_install_domain_solver()


GRID_W = 64
GRID_H = 64
MAP_H = 54
UI_Y = 56
BUTTON_H = 7

BACKGROUND = 0
FLOOR = 9
WALL = 5
PLAYER = 1
GOAL = 3
CURSOR = 15
PRESSED = 13

BUTTON_COLORS = [4, 6, 7, 8, 11, 12, 14, 15]
OBSTACLE_COLORS = [2, 4, 6, 8, 10]
OBSTACLE_COUNT = 5
STONE_COUNTS = [23, 30, 40, 50]
FACING_PIXELS = {
    (1, 0): [[PLAYER, CURSOR], [PLAYER, CURSOR]],
    (-1, 0): [[CURSOR, PLAYER], [CURSOR, PLAYER]],
    (0, -1): [[CURSOR, CURSOR], [PLAYER, PLAYER]],
    (0, 1): [[PLAYER, PLAYER], [CURSOR, CURSOR]],
}
LETTER_PATTERNS = {
    "Y": ["101", "101", "010", "010", "010"],
    "O": ["111", "101", "101", "101", "111"],
    "U": ["101", "101", "101", "101", "111"],
    "W": ["101", "101", "101", "111", "101"],
    "I": ["111", "010", "010", "010", "111"],
    "N": ["101", "111", "111", "111", "101"],
}
DIGIT_PATTERNS = {
    1: ["010", "110", "010", "010", "111"],
    2: ["111", "001", "111", "100", "111"],
    3: ["111", "001", "111", "001", "111"],
    4: ["101", "101", "111", "001", "001"],
}

DIRS = {
    GameAction.ACTION1: (0, -1),
    GameAction.ACTION2: (0, 1),
    GameAction.ACTION3: (-1, 0),
    GameAction.ACTION4: (1, 0),
}


@dataclass(frozen=True)
class LevelConfig:
    name: str
    button_count: int
    branch_count: int


LEVEL_CONFIGS = [
    LevelConfig("easy", 4, 4),
    LevelConfig("medium", 4, 6),
    LevelConfig("hard", 4, 8),
    LevelConfig("very hard", 4, 10),
]

LEVELS = [
    Level(sprites=[], grid_size=(GRID_W, GRID_H), name=config.name)
    for config in LEVEL_CONFIGS
]


class ElementalPaths(BaseGame):
    game_name = "Elemental Paths"
    description = "Keyboard and click controls reveal a turn-based elemental path puzzle."
    category = "agentic"
    primitive_tags = [
        "pathfinding",
        "topology",
        "sequence",
        "non_commutative",
        "combining_rule_opacity",
        "state_transform",
    ]
    feedback_tier = 2

    def __init__(self, seed: int = 0) -> None:
        self._rng = random.Random(seed)
        self._level_rng = random.Random(seed)
        self._free_cells: set[tuple[int, int]] = set()
        self._solution_path: list[tuple[int, int]] = []
        self._button_rects: list[tuple[int, int, int, int]] = []
        self._positive_spells: dict[tuple[int, ...], int] = {}
        self._negative_spells: set[tuple[int, ...]] = set()
        self._selected_spell: list[int] = []
        self._cursor_index = 0
        self._spell_mode = False
        self._facing = (1, 0)
        self._last_player_pos = (3, 4)
        self._obstacle_serial = 0
        self._projectile_path: list[tuple[int, int]] = []
        self._projectile_target: Sprite | None = None
        self._projectile_destroys = False
        self._projectile_color = CURSOR
        self._show_win_banner_on_next_level = False

        camera = Camera(background=BACKGROUND, letter_box=WALL, width=GRID_W, height=GRID_H)
        super().__init__(
            game_id="elemental_paths",
            levels=LEVELS,
            camera=camera,
            available_actions=[1, 2, 3, 4, 5, 6, 7],
            seed=seed,
        )

    def handle_reset(self) -> None:
        """Keep browser level-jump testing on the selected level."""
        if self.state.value == "WIN" or self.level_index == 0:
            self.full_reset()
        else:
            self.level_reset()

    def on_set_level(self, level: Level) -> None:
        level.remove_all_sprites()
        self._selected_spell = []
        self._cursor_index = 0
        self._spell_mode = False
        self._facing = (1, 0)
        self._obstacle_serial = 0
        self._projectile_path = []
        self._projectile_target = None
        self._projectile_destroys = False
        self._projectile_color = CURSOR
        self._generate_level(level)
        if self._show_win_banner_on_next_level:
            self._add_win_banner(level)
            self._show_win_banner_on_next_level = False

    def _generate_level(self, level: Level) -> None:
        config = LEVEL_CONFIGS[self.level_index]
        self._level_rng = random.Random(self._rng.randint(0, 10_000_000))
        self._free_cells, self._solution_path = self._make_winding_map(config)
        self._positive_spells, self._negative_spells = self._make_spellbook(config.button_count)
        self._button_rects = self._make_button_rects(config.button_count)

        self._add_map_sprites(level)
        self._add_goal(level)
        self._add_player(level)
        self._add_obstacles(level)
        self._add_buttons(level)
        self._refresh_spell_ui()

    def _make_winding_map(self, config: LevelConfig) -> tuple[set[tuple[int, int]], list[tuple[int, int]]]:
        offset = self.level_index * 2
        waypoints = [
            (3, 4),
            (14 + offset, 5),
            (9, 15),
            (24, 18 + offset),
            (16, 29),
            (34 + offset, 31),
            (31, 14),
            (49, 11 + offset),
            (56, 26),
            (45, 40),
            (28, 43),
            (39, 50),
            (58, 48),
        ]
        path = self._connect_waypoints(waypoints)

        free = {
            (x, y)
            for y in range(2, MAP_H - 2)
            for x in range(1, GRID_W - 1)
        }

        return free, path

    def _connect_waypoints(self, points: list[tuple[int, int]]) -> list[tuple[int, int]]:
        path: list[tuple[int, int]] = [points[0]]
        x, y = points[0]
        for tx, ty in points[1:]:
            while x != tx:
                x += 1 if tx > x else -1
                path.append((x, y))
            while y != ty:
                y += 1 if ty > y else -1
                path.append((x, y))
        return path

    def _make_spellbook(self, button_count: int) -> tuple[dict[tuple[int, ...], int], set[tuple[int, ...]]]:
        all_buttons = list(range(button_count))
        positive: dict[tuple[int, ...], int] = {}
        used: set[tuple[int, ...]] = set()

        for obstacle_type in range(OBSTACLE_COUNT):
            combo = tuple(self._level_rng.sample(all_buttons, button_count))
            while combo in used:
                combo = tuple(self._level_rng.sample(all_buttons, button_count))
            positive[combo] = obstacle_type
            used.add(combo)

        negative: set[tuple[int, ...]] = set()
        negative_count = max(2, button_count - 2)
        while len(negative) < negative_count:
            combo = tuple(self._level_rng.sample(all_buttons, button_count))
            if combo not in used:
                negative.add(combo)
                used.add(combo)

        return positive, negative

    def _make_button_rects(self, button_count: int) -> list[tuple[int, int, int, int]]:
        gap = 1
        total_gap = gap * (button_count + 1)
        width = max(5, (GRID_W - total_gap) // button_count)
        used = width * button_count + total_gap
        x = max(0, (GRID_W - used) // 2) + gap
        rects = []
        for _ in range(button_count):
            rects.append((x, UI_Y, width, BUTTON_H))
            x += width + gap
        return rects

    def _add_map_sprites(self, level: Level) -> None:
        wall_pixels: list[list[int]] = []
        floor_pixels: list[list[int]] = []
        for y in range(MAP_H + 2):
            wall_row = []
            floor_row = []
            for x in range(GRID_W):
                if y >= MAP_H or (x, y) not in self._free_cells:
                    wall_row.append(WALL)
                    floor_row.append(-1)
                else:
                    wall_row.append(-1)
                    floor_row.append(FLOOR)
            wall_pixels.append(wall_row)
            floor_pixels.append(floor_row)

        level.add_sprite(Sprite(floor_pixels, name="floor", x=0, y=0, layer=0, visible=True, collidable=False))
        level.add_sprite(Sprite(wall_pixels, name="walls", x=0, y=0, layer=1, tags=["wall", "sys_static"]))

    def _add_goal(self, level: Level) -> None:
        gx, gy = self._solution_path[-1]
        level.add_sprite(Sprite([[GOAL, GOAL], [GOAL, GOAL]], name="goal", x=gx, y=gy, layer=2, visible=True, collidable=False, tags=["goal"]))

    def _add_player(self, level: Level) -> None:
        start = self._solution_path[0]
        self._last_player_pos = start
        level.add_sprite(Sprite(FACING_PIXELS[self._facing], name="player", x=start[0], y=start[1], layer=5, tags=["player"]))

    def _add_obstacles(self, level: Level) -> None:
        for x, y in self._fixed_obstacle_centers():
            level.add_sprite(self._make_obstacle_sprite(self._random_obstacle_type(), x, y))

    def _random_obstacle_type(self) -> int:
        return self._level_rng.randrange(OBSTACLE_COUNT)

    def _fixed_obstacle_centers(self) -> list[tuple[int, int]]:
        if self.level_index == 0:
            return self._level_one_centers()

        target_count = STONE_COUNTS[self.level_index]
        path_blocks = [4, 10, 14, 18][self.level_index]
        centers: list[tuple[int, int]] = []
        for path_index in self._fixed_path_block_indexes(path_blocks):
            centers.append(self._solution_path[path_index])

        centers.extend(self._fixed_map_centers())

        unique_centers = []
        seen: set[tuple[int, int]] = set()
        protected = set(self._solution_path[:8]) | set(self._solution_path[-8:])
        for center in centers:
            if center in seen or center in protected:
                continue
            seen.add(center)
            unique_centers.append(center)
            if len(unique_centers) == target_count:
                break
        return unique_centers

    def _level_one_centers(self) -> list[tuple[int, int]]:
        return [
            (6, 13), (6, 29), (6, 44),
            (18, 6), (33, 6), (48, 6),
            (57, 14), (57, 29), (56, 41),
            (16, 50), (31, 50), (46, 50),
            (18, 16), (34, 16), (49, 20),
            (14, 26), (30, 27), (45, 29),
            (18, 38), (34, 39), (49, 37),
            (25, 44), (40, 23),
        ]

    def _fixed_map_centers(self) -> list[tuple[int, int]]:
        edge_centers = [
            (5, 12), (5, 27), (5, 43),
            (16, 50), (31, 50), (47, 50),
            (57, 13), (57, 28), (57, 43),
            (17, 5), (32, 5), (48, 5),
            (22, 20), (39, 33),
            (14, 35), (50, 20), (28, 44), (42, 13),
        ]
        interior_centers = [
            (24, 12), (43, 28), (31, 41),
            (17, 14), (32, 15), (46, 16),
            (15, 25), (29, 26), (43, 26),
            (19, 36), (34, 36), (49, 37),
            (25, 43), (40, 44),
            (23, 20), (38, 21),
            (22, 31), (37, 31),
            (14, 40), (52, 23),
            (29, 10), (48, 32), (12, 19),
            (17, 13), (29, 13), (42, 14), (51, 14),
            (14, 23), (25, 23), (37, 24), (49, 24),
            (16, 33), (28, 33), (40, 34), (52, 34),
            (14, 43), (37, 44), (49, 44),
        ]
        return edge_centers + interior_centers

    def _fixed_path_block_indexes(self, count: int) -> list[int]:
        min_index = max(8, len(self._solution_path) // 12)
        max_index = min(len(self._solution_path) - 8, len(self._solution_path) * 11 // 12)
        span = max_index - min_index
        indexes: list[int] = []
        for segment in range(count):
            start = min_index + span * segment // count
            end = min_index + span * (segment + 1) // count
            if end <= start:
                continue
            indexes.append((start + end) // 2)
        return indexes

    def _near_solution_path(self, x: int, y: int, radius: int) -> bool:
        for px, py in self._solution_path:
            if abs(x - px) + abs(y - py) <= radius:
                return True
        return False

    def _make_obstacle_sprite(self, obstacle_type: int, center_x: int, center_y: int) -> Sprite:
        self._obstacle_serial += 1
        radius = 5 + min(2, self.level_index)
        pixels = self._make_stone_blob_pixels(OBSTACLE_COLORS[obstacle_type], radius)
        x = max(1, min(GRID_W - len(pixels[0]) - 1, center_x - radius))
        y = max(2, min(MAP_H - len(pixels) - 2, center_y - radius))
        return Sprite(
            pixels,
            name=f"obstacle_{self._obstacle_serial}",
            x=x,
            y=y,
            layer=4,
            tags=["obstacle", f"obstacle_{obstacle_type}"],
        )

    def _make_stone_blob_pixels(self, color: int, radius: int) -> list[list[int]]:
        size = radius * 2 + 1
        pixels: list[list[int]] = []
        for y in range(size):
            row = []
            for x in range(size):
                dx = abs(x - radius)
                dy = abs(y - radius)
                edge_noise = self._level_rng.randint(0, 2)
                if dx + dy <= radius + edge_noise and max(dx, dy) <= radius:
                    row.append(color)
                else:
                    row.append(-1)
            pixels.append(row)
        return pixels

    def _add_buttons(self, level: Level) -> None:
        for idx, (x, y, w, h) in enumerate(self._button_rects):
            color = BUTTON_COLORS[idx]
            pixels = [[color for _ in range(w)] for _ in range(h)]
            level.add_sprite(
                Sprite(
                    pixels,
                    name=f"button_{idx}",
                    x=x,
                    y=y,
                    layer=3,
                    tags=["button", "sys_click", f"button_{idx}"],
                )
            )

    def step(self) -> None:
        if self._projectile_path:
            self._advance_projectile()
            if self._projectile_path:
                return
            self._check_goal()
            self._refresh_spell_ui()
            self.complete_action()
            return

        self._clear_projectiles()
        self._clear_win_banner()
        action = self.action.id

        if action in DIRS:
            dx, dy = DIRS[action]
            self._move_player(dx, dy)
        elif action == GameAction.ACTION5:
            if not self._spell_mode:
                self._spell_mode = True
            else:
                self._press_button(self._cursor_index)
        elif action == GameAction.ACTION6:
            self._handle_click()
        elif action == GameAction.ACTION7:
            self._spell_mode = True
            self._move_cursor_delta(1)

        self._check_goal()
        self._refresh_spell_ui()
        if self._projectile_path:
            return
        self.complete_action()

    def _move_player(self, dx: int, dy: int) -> None:
        self._facing = (dx, dy)
        player = self._player()
        player.pixels = np.array(FACING_PIXELS[self._facing], dtype=np.int8)
        self._last_player_pos = (player.x, player.y)
        self.try_move("player", dx, dy)

    def _move_spell_cursor(self, action: GameAction) -> None:
        if action in (GameAction.ACTION3, GameAction.ACTION1):
            self._move_cursor_delta(-1)
        elif action in (GameAction.ACTION4, GameAction.ACTION2):
            self._move_cursor_delta(1)

    def _move_cursor_delta(self, delta: int) -> None:
        if not self._button_rects:
            return
        count = len(self._button_rects)
        for step in range(1, count + 1):
            candidate = (self._cursor_index + delta * step) % count
            if candidate not in self._selected_spell:
                self._cursor_index = candidate
                return
        self._cursor_index = (self._cursor_index + delta) % count

    def _handle_click(self) -> None:
        coords = self.camera.display_to_grid(self.action.get_x(), self.action.get_y())
        if not coords:
            return
        gx, gy = coords
        button_index = self._button_at(gx, gy)
        if button_index is not None:
            self._spell_mode = True
            self._cursor_index = button_index
            self._press_button(button_index)
            return
        if gy < MAP_H:
            self._click_move(gx, gy)

    def _click_move(self, gx: int, gy: int) -> None:
        player = self._player()
        dx_total = gx - player.x
        dy_total = gy - player.y
        if abs(dx_total) > abs(dy_total):
            dx, dy = (1 if dx_total > 0 else -1), 0
        elif dy_total != 0:
            dx, dy = 0, (1 if dy_total > 0 else -1)
        else:
            return
        self._move_player(dx, dy)

    def _button_at(self, gx: int, gy: int) -> int | None:
        for idx, (x, y, w, h) in enumerate(self._button_rects):
            if x <= gx < x + w and y <= gy < y + h:
                return idx
        return None

    def _press_button(self, index: int) -> None:
        if index in self._selected_spell:
            return
        self._selected_spell.append(index)
        self._move_cursor_delta(1)
        if len(self._selected_spell) == len(self._button_rects):
            combo = tuple(self._selected_spell)
            self._resolve_spell(combo)
            self._selected_spell = []
            self._spell_mode = False

    def _resolve_spell(self, combo: tuple[int, ...]) -> None:
        if combo in self._positive_spells:
            self._cast_positive_spell(self._positive_spells[combo])
        elif combo in self._negative_spells:
            self._cast_negative_spell()

    def _cast_positive_spell(self, obstacle_type: int) -> None:
        hit, path = self._ray_to_first_obstacle()
        if hit:
            self._start_projectile(hit, path, f"obstacle_{obstacle_type}" in hit.tags, OBSTACLE_COLORS[obstacle_type])

    def _cast_negative_spell(self) -> None:
        position = self._find_new_stone_position()
        if position is None:
            return
        obstacle_type = self._level_rng.randrange(OBSTACLE_COUNT)
        self.current_level.add_sprite(self._make_obstacle_sprite(obstacle_type, position[0], position[1]))

    def _find_new_stone_position(self) -> tuple[int, int] | None:
        player = self._player()
        goal = self.current_level.get_sprites_by_name("goal")[0]
        protected = {(player.x, player.y), (goal.x, goal.y)}
        protected.update(self._solution_path[:6])
        protected.update(self._solution_path[-6:])

        for _ in range(80):
            x = self._level_rng.randint(6, GRID_W - 7)
            y = self._level_rng.randint(7, MAP_H - 8)
            if (x, y) in protected:
                continue
            if self.current_level.get_sprite_at(x, y, tag="obstacle") is None:
                return x, y
        return None

    def _ray_to_first_obstacle(self) -> tuple[Sprite | None, list[tuple[int, int]]]:
        player = self._player()
        dx, dy = self._facing
        x = player.x + (2 if dx > 0 else -1 if dx < 0 else 0)
        y = player.y + (2 if dy > 0 else -1 if dy < 0 else 0)
        path: list[tuple[int, int]] = []
        while 0 <= x < GRID_W and 0 <= y < MAP_H:
            path.append((x, y))
            probe_cells = [(x, y)]
            if dx != 0:
                probe_cells.append((x, y + 1))
            if dy != 0:
                probe_cells.append((x + 1, y))
            for px, py in probe_cells:
                sprite = self.current_level.get_sprite_at(px, py, tag="obstacle")
                if sprite:
                    return sprite, path
                if (px, py) not in self._free_cells:
                    return None, path
            x += dx
            y += dy
        return None, path

    def _start_projectile(self, target: Sprite, path: list[tuple[int, int]], destroys: bool, color: int) -> None:
        self._projectile_path = path[:]
        self._projectile_target = target
        self._projectile_destroys = destroys
        self._projectile_color = color
        self._advance_projectile()

    def _advance_projectile(self) -> None:
        if not self._projectile_path:
            return

        x, y = self._projectile_path.pop(0)
        self.current_level.add_sprite(
            Sprite([[self._projectile_color]], name=f"projectile_{x}_{y}", x=x, y=y, layer=8, visible=True, collidable=False, tags=["projectile"])
        )

        if not self._projectile_path:
            if self._projectile_destroys and self._projectile_target:
                self.current_level.remove_sprite(self._projectile_target)
            self._projectile_target = None
            self._projectile_destroys = False

    def _clear_projectiles(self) -> None:
        for sprite in self.current_level.get_sprites_by_tag("projectile"):
            self.current_level.remove_sprite(sprite)

    def _check_goal(self) -> None:
        player = self._player()
        goal = self.current_level.get_sprites_by_name("goal")[0]
        if player.x == goal.x and player.y == goal.y:
            self._add_win_banner(self.current_level)
            if not self.is_last_level():
                self._show_win_banner_on_next_level = True
            self.next_level()

    def _is_free_for_player(self, x: int, y: int) -> bool:
        if (x, y) not in self._free_cells:
            return False
        return self.current_level.get_sprite_at(x, y, tag="obstacle") is None

    def _player(self) -> Sprite:
        return self.current_level.get_sprites_by_name("player")[0]

    def _add_win_banner(self, level: Level) -> None:
        self._clear_win_banner()
        pixels = self._text_pixels("YOU WIN", foreground=CURSOR, background=0)
        x = (GRID_W - len(pixels[0])) // 2
        y = 24
        level.add_sprite(
            Sprite(pixels, name="you_win_banner", x=x, y=y, layer=9, visible=True, collidable=False, tags=["win_banner"])
        )

    def _clear_win_banner(self) -> None:
        for sprite in self.current_level.get_sprites_by_tag("win_banner"):
            self.current_level.remove_sprite(sprite)

    def _text_pixels(self, text: str, foreground: int, background: int) -> list[list[int]]:
        rows = [[] for _ in range(7)]
        for char in text:
            if char == " ":
                for row in rows:
                    row.extend([background, background])
                continue
            pattern = LETTER_PATTERNS[char]
            for row_index, pattern_row in enumerate(pattern):
                rows[row_index + 1].extend(foreground if cell == "1" else background for cell in pattern_row)
                rows[row_index + 1].append(background)
            for row_index in (0, 6):
                rows[row_index].extend([background, background, background, background])
        return rows

    def _refresh_spell_ui(self) -> None:
        for sprite in self.current_level.get_sprites_by_tag("spell_ui"):
            self.current_level.remove_sprite(sprite)

        for order, idx in enumerate(self._selected_spell, start=1):
            x, y, w, _ = self._button_rects[idx]
            pixels = [
                [CURSOR if cell == "1" else -1 for cell in row]
                for row in DIGIT_PATTERNS[order]
            ]
            digit_x = x + max(0, (w - 3) // 2)
            digit_y = y + 1
            marker = Sprite(
                pixels,
                name=f"pressed_order_{order}",
                x=digit_x,
                y=digit_y,
                layer=8,
                visible=True,
                collidable=False,
                tags=["spell_ui"],
            )
            self.current_level.add_sprite(marker)

        if self._button_rects:
            x, y, w, h = self._button_rects[self._cursor_index]
            color = CURSOR if self._spell_mode else PRESSED
            top = [color for _ in range(w)]
            middle = [color] + [-1 for _ in range(max(0, w - 2))] + ([color] if w > 1 else [])
            pixels = [top] + [middle for _ in range(max(0, h - 2))] + [top]
            self.current_level.add_sprite(Sprite(pixels, name="spell_cursor", x=x, y=y, layer=7, visible=True, collidable=False, tags=["spell_ui"]))
