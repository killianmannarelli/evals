"""Verify Elemental Paths solvability. Run: python verify.py"""

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent.parent))
sys.path.insert(0, str(Path(__file__).resolve().parent))

from elemental_paths import ElementalPaths
from ipe.enums import ActionInput, GameAction


MOVE_ACTIONS = {
    (0, -1): GameAction.ACTION1,
    (0, 1): GameAction.ACTION2,
    (-1, 0): GameAction.ACTION3,
    (1, 0): GameAction.ACTION4,
}


def perform(game: ElementalPaths, action: GameAction, data: dict | None = None) -> str:
    result = game.perform_action(ActionInput(id=action, data=data or {}))
    return result.state.value


def click_button(game: ElementalPaths, button_index: int) -> str:
    x, y, w, h = game._button_rects[button_index]
    return perform(game, GameAction.ACTION6, {"x": x + w // 2, "y": y + h // 2})


def cast_for_obstacle(game: ElementalPaths, obstacle_type: int) -> str:
    combo = None
    for sequence, mapped_type in game._positive_spells.items():
        if mapped_type == obstacle_type:
            combo = sequence
            break
    if combo is None:
        raise AssertionError(f"No positive spell for obstacle {obstacle_type}")

    state = "NOT_FINISHED"
    for button_index in combo:
        state = click_button(game, button_index)
    return state


def obstacle_type_at_player_target(game: ElementalPaths, x: int, y: int) -> int | None:
    probe_cells = [(x, y), (x + 1, y), (x, y + 1), (x + 1, y + 1)]
    obstacle = None
    for px, py in probe_cells:
        obstacle = game.current_level.get_sprite_at(px, py, tag="obstacle")
        if obstacle:
            break
    if not obstacle:
        return None
    for tag in obstacle.tags:
        if tag.startswith("obstacle_") and tag != "obstacle":
            return int(tag.split("_")[1])
    return None


def solve_current_level(game: ElementalPaths) -> str:
    path = list(game._solution_path)
    state = "NOT_FINISHED"
    for current, nxt in zip(path, path[1:]):
        dx = nxt[0] - current[0]
        dy = nxt[1] - current[1]
        move_action = MOVE_ACTIONS[(dx, dy)]

        for _ in range(25):
            obstacle_type = obstacle_type_at_player_target(game, nxt[0], nxt[1])
            if obstacle_type is None:
                break
            # Face the blocker first; the failed move proves the spell ray collides with it.
            state = perform(game, move_action)
            if state in ("WIN", "GAME_OVER"):
                return state
            state = cast_for_obstacle(game, obstacle_type)
            if state in ("WIN", "GAME_OVER"):
                return state
        if obstacle_type_at_player_target(game, nxt[0], nxt[1]) is not None:
            return "GAME_OVER"

        state = perform(game, move_action)
        if state in ("WIN", "GAME_OVER"):
            return state
    return state


print("Elemental Paths")
print("Verifying all levels across 20 seeds...")
print()

all_ok = True
for seed in range(20):
    game = ElementalPaths(seed=seed)
    perform(game, GameAction.RESET)

    cleared = 0
    failed = False
    for _ in range(game.num_levels):
        state = solve_current_level(game)
        if state == "GAME_OVER":
            failed = True
            break
        cleared = game.score
        if state == "WIN":
            break

    status = "OK" if cleared == game.num_levels and not failed else "FAIL"
    print(f"  Seed {seed:2d}: [{status}] {cleared}/{game.num_levels} levels cleared")
    if status != "OK":
        all_ok = False

print()
if all_ok:
    print("All seeds solvable!")
else:
    print("SOME SEEDS FAILED - check map/spell generation.")
