# Elemental Paths

Turn-based agentic puzzle using Non-Commutativity, Map Topology, and Combining Rule Opacity.

## Files

- `elemental_paths.py`: main game logic.
- `run.py`: starts the browser server.
- `verify.py`: programmatic solvability verification.
- `requirements.txt`: dependencies.
- `play_logs/`: created by browser play.

## Controls

- `WASD` / arrow actions: move the character on the map.
- `Space` / `F`: enter spell mode or press the selected elemental button.
- `Z`: move the spell selector to the next available button.
- Mouse click: move on the map or press bottom buttons.
- `R`: reset.

The in-frame puzzle does not reveal spell rules or solution logic.
