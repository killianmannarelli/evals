# Polarity Tiles

A non-agentic spatial-assembly puzzle: cover every light-green target cell on the board by placing polarised tiles from the tray. Adjacent tiles **react** the moment a tile lands — same polarity repels (and may fly tiles off the board for good), opposite polarity locks them together.

## Controls

- **Click a tile in the tray** (the row beneath the gray separator) to select it. A small white indicator appears above the selected tile.
- **Click an empty cell on the board** to place the selected tile.
- **Z** (ACTION7): undo the last placement and all reactions it caused. One step only.
- **R** (RESET): restart the current level.

The polarity of each tile is shown by a single corner pixel inside it:

- **`+` polarity** — small **white** pixel in the top-left corner. Colours: red, yellow, orange.
- **`−` polarity** — small **black** pixel in the top-left corner. Colours: blue, magenta, light blue.

(Colour is a redundant cue — warm = `+`, cool = `−` — but the corner pixel is the authoritative signal.)

## Reaction rules

The instant you place a tile, the engine checks its 4 orthogonal neighbours in fixed order (up, right, down, left). For each neighbour that holds a tile:

- **Same polarity** → both tiles fly apart along the axis of contact, sliding to the farthest empty cell before any wall, edge, or other tile. **If a tile's path to the edge is unobstructed, it flies off the board and is removed from play permanently.**
- **Opposite polarity** → both tiles **lock** in place. Locked tiles still cover any target underneath them, and they no longer fly in subsequent reactions. A small gray pixel appears in the bottom-right corner of a locked tile.

Reactions never cascade. A tile that slides into a new neighbourhood does not trigger fresh reactions there. Only the originally-placed tile starts a reaction chain.

## Levels

| # | Name      | Board | Targets | Tiles | Walls |
|---|-----------|-------|---------|-------|-------|
| 1 | Easy      | 6×6   | 3       | 5     | 1     |
| 2 | Medium    | 8×8   | 5       | 7     | 3     |
| 3 | Hard      | 10×10 | 7       | 9     | 4     |
| 4 | Very Hard | 12×12 | 10      | 12    | 7     |

Each level always has at least 2 spare tiles in the tray. Lose one to a same-polarity edge ejection, and you can still recover. Lose three, and you're stuck.

## Difficulty levers

The puzzle uses three of the project's difficulty levers:

1. **Action Coupling.** A single placement triggers multiple side-effects (4 neighbour checks, each potentially moving two tiles). The player can't reason about a click in isolation — they have to predict the chain.
2. **Non-Commutativity.** Placement order changes the outcome. Placing tile A then B can leave them locked together; placing B then A might fire one of them off the board first.
3. **Irreversible Actions.** A tile that flies off the board is gone. Combined with one-step undo, this forces the player to commit to placements they fully understand and to use the undo budget for genuine recoveries rather than blind exploration.

## Novelty

Polarity Tiles takes the classic tile-placement puzzle (covering a set of target cells from a fixed inventory) and adds a magnetism-style reaction layer. Most placement puzzles let you commit to a position and undo at will; here the act of placing is also the act of triggering a physics chain that can permanently lose you a tile. Solving requires both the spatial planning of a packing puzzle and the look-ahead of a chain-reaction puzzle, expressed entirely through clicks on a 64×64 grid with no text prompts.
