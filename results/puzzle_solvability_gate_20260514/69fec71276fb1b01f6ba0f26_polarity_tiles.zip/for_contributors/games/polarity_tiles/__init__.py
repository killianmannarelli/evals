from .polarity_tiles import PolarityTilesGame

__all__ = ["PolarityTilesGame"]
