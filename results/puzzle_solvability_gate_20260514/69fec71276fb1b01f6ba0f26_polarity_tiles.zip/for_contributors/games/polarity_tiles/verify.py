"""verify.py — 200 solvability proofs (50 seeds × 4 levels).

For each (seed, level) we build a fresh PolarityTilesGame, jump to that level
via set_level(), then play a direct-placement solution through the actual
engine: for each target cell we issue ACTION6 to select a tile in the tray,
then ACTION6 again to place it on the target.

Why this works: _try_generate guarantees no two target cells are orthogonally
adjacent, so placing one tile per target in any order never triggers a
reaction. The level is therefore solvable in exactly len(targets) placements.

Verifying through perform_action (rather than internal simulation) exercises
the same code path the recorded play log will hit at submission time, so a
clean run here is strong evidence the play log replay will validate.
"""

from __future__ import annotations

import sys
from pathlib import Path

_root = str(Path(__file__).resolve().parent.parent.parent)
sys.path.insert(0, _root)
sys.path.insert(0, str(Path(__file__).resolve().parent))

from polarity_tiles import PolarityTilesGame
from ipe.enums import ActionInput, GameAction, GameState


def _click(game, grid_x: int, grid_y: int):
    """Issue ACTION6 with display coords centred on the given grid cell."""
    scale, xo, yo = game.camera._calculate_scale_and_offset()
    dx = grid_x * scale + xo + scale // 2
    dy = grid_y * scale + yo + scale // 2
    return game.perform_action(ActionInput(id=GameAction.ACTION6, data={"x": dx, "y": dy}))


def _solve_one(seed: int, level_idx: int):
    """Run the direct-placement solution. Returns (ok, placements, message)."""
    game = PolarityTilesGame(seed=seed)
    game.set_level(level_idx)

    targets_snapshot = list(game._world["targets"])
    tray_snapshot = game._world["tray"]
    N = game._N
    score_before = game.score

    placements = 0
    used: set[int] = set()
    for tx, ty in targets_snapshot:
        # Pick the first unused tile from the tray. Any tile works because
        # non-adjacent targets mean no reactions trigger.
        chosen = None
        for i, t in enumerate(tray_snapshot):
            if i in used or t["used"]:
                continue
            chosen = i
            break
        if chosen is None:
            return False, placements, "ran out of tray tiles before all targets covered"
        used.add(chosen)

        # Click 1: select the tile in the tray.
        _click(game, 3 * chosen, 2 * N + 2)
        # Click 2: place on the target cell (logical (tx,ty) = grid (2tx,2ty)).
        result = _click(game, 2 * tx, 2 * ty)
        placements += 1

        if result.state == GameState.WIN:
            return True, placements, "WIN"
        if game.score > score_before:
            return True, placements, "level cleared"
        if result.state == GameState.GAME_OVER:
            return False, placements, "GAME_OVER mid-solve"

    if game.score > score_before:
        return True, placements, "level cleared"
    uncovered = set(targets_snapshot) - set(game._world["board"].keys())
    if not uncovered:
        return True, placements, "all targets covered"
    return False, placements, f"uncovered targets: {sorted(uncovered)}"


def main() -> int:
    print("polarity_tiles — verify.py")
    print("Verifying 4 levels × 50 seeds = 200 layouts via the live engine path...")
    print()

    total = 0
    passed = 0
    failures: list[tuple[int, int, str]] = []
    for seed in range(50):
        for level_idx in range(4):
            total += 1
            ok, placements, msg = _solve_one(seed, level_idx)
            if ok:
                passed += 1
                print(f"  seed {seed:2d}  L{level_idx+1}: [SOLVABLE] in {placements} placements  ({msg})")
            else:
                failures.append((seed, level_idx, msg))
                print(f"  seed {seed:2d}  L{level_idx+1}: [FAIL] {msg}")

    print()
    print(f"TOTAL: {passed}/{total} SOLVABLE")
    if failures:
        print()
        print(f"FAILURES ({len(failures)}):")
        for seed, lvl, msg in failures[:20]:
            print(f"  seed={seed} level={lvl+1}: {msg}")
        return 1
    return 0


if __name__ == "__main__":
    sys.exit(main())
