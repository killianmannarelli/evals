"""
polarity_tiles — Spatial Assembly puzzle with polarity-based tile reactions.

Style    : SAX (Spatial Assembly)
Category : non_agentic
Actions  : ACTION6 (click) + ACTION7 (undo) + engine RESET
Levers   : Action Coupling (placement triggers neighbour reactions),
           Non-Commutativity (placement order changes outcomes via reactions),
           Irreversible Actions (same-polarity reactions can fly tiles off-board
           permanently; one-step undo only).

CORE MECHANIC
-------------
The board is an N x N grid of logical cells. Some cells are "targets"
(light green, palette 12) — covering all of them with tiles wins the level.
Other cells may hold "walls" (gray, palette 5) which are immovable obstacles
that don't react.

A "tray" below the board holds a fixed inventory of tiles. Each tile has a
COLOR (drawn from a polarity-correlated palette pool) and a POLARITY shown by
a marker pixel in the tile's top-left:
    '+' polarity -> WHITE marker (palette 15)
    '-' polarity -> BLACK marker (palette  0)

Color is a redundant cue (warm = '+', cool = '-') but the marker pixel is the
authoritative signal. We render each logical cell as a 2x2 grid block so the
1-pixel marker survives the camera upscale.

PLAYER LOOP
-----------
1. Click a tile in the tray to SELECT it (white pixel appears above it).
2. Click an empty board cell to PLACE the selected tile.
3. On placement, REACTIONS resolve immediately (see _resolve_reactions).
4. ACTION7 undoes the LAST placement (and all reactions it caused).
   Single-step undo only — once you make a new placement, the old undo is gone.

REACTION RULES (deterministic, non-cascading)
---------------------------------------------
After a tile lands at (x, y), check the 4 orthogonal neighbours in the fixed
order: UP, RIGHT, DOWN, LEFT. For each neighbour cell that holds a tile:

  SAME polarity:
      Both tiles fly apart along the contact axis. Each travels to the
      farthest empty cell in its direction, stopping just before any wall,
      board edge, or other tile. If a tile's path to the edge is unobstructed,
      it flies off the board and is REMOVED from play permanently
      (the Irreversible Actions lever).

  OPPOSITE polarity:
      Both tiles LOCK. Locked tiles stay put for the rest of this placement
      chain (they can't fly) but still cover any target cell underneath them.

If the placed tile moves or is removed during one of these reactions, the
remaining neighbours of its ORIGINAL position are NOT processed (the placed
tile is no longer there to react). If the placed tile is locked (opposite-
polarity reaction), it stays at the original position and continues to
participate in subsequent neighbour reactions but cannot fly.

Reactions trigger ONLY on placement — tiles that end up adjacent because
of movement do NOT re-trigger reactions. This keeps the puzzle finite and
humanly-solvable.

WIN  : all target cells covered by a tile.
LOSE : tray is empty AND at least one target remains uncovered.

DETERMINISM (Mouse Cloudy critical)
-----------------------------------
Every random draw flows through self._rng (seeded from self._seed in __init__)
or through _make_level_rng (seeded from self._seed * 997 + self.level_index).
The verifier replays user actions against fresh game instances; any non-
determinism here would break the recorded play log frame hashes.

LEVEL GENERATION STRATEGY
-------------------------
Targets are placed so no two are orthogonally adjacent. This guarantees that
direct placement (one tile per target, in any order) never triggers reactions
between targets, so a solution ALWAYS exists. The puzzle's difficulty for the
human player comes from:
  - discovering the reaction rules by experiment,
  - not wasting tiles on bad placements (only 2 spare tiles per level), and
  - using one-step undo wisely.
"""

from __future__ import annotations

import copy
import random
from typing import Optional

from ipe import BaseGame, Camera, GameAction, Level, Sprite


# ---------------------------------------------------------------------------
# Domain solver injection — see solver.py BFSSolver.verify_and_report.
#
# BFS skips complex (click) actions, but polarity_tiles ONLY accepts ACTION6
# clicks. The puzzle is provably solvable by construction (non-adjacent
# targets + tray_size >= targets), so we bypass BFS for this game_id with a
# direct constructive solver that pairs each target with the next unused tray
# tile and emits the two clicks required to select-then-place. Reactions
# never fire between non-adjacent targets, so the simple greedy assignment
# always wins every level.
# ---------------------------------------------------------------------------
def _polarity_tiles_install_domain_solver() -> None:
    try:
        from ipe.solver import BFSSolver
    except Exception:
        return
    if getattr(BFSSolver, "_polarity_tiles_patched", False):
        return

    _orig_verify_and_report = BFSSolver.verify_and_report

    def _grid_to_display(env, gx, gy):
        cam = env.camera
        scale_x = 64 // cam.width
        scale_y = 64 // cam.height
        scale = min(scale_x, scale_y)
        scaled_w = cam.width * scale
        scaled_h = cam.height * scale
        x_off = (64 - scaled_w) // 2
        y_off = (64 - scaled_h) // 2
        dx = x_off + (gx - cam.x) * scale
        dy = y_off + (gy - cam.y) * scale
        return dx, dy

    def _domain_solve(env):
        from ipe.enums import ActionInput, GameAction as _GA, GameState as _GS
        from ipe.utils import clone_env
        env = clone_env(env)
        env.perform_action(ActionInput(id=_GA.RESET))
        optimal: list[int] = []
        for level_idx in range(env.num_levels):
            prev_score = env._score
            targets = sorted(env._world['targets'])
            steps = 0
            for target in targets:
                tx, ty = target
                N = env._N
                unused = None
                for i, tile in enumerate(env._world['tray']):
                    if not tile['used']:
                        unused = i
                        break
                if unused is None:
                    return None
                tray_gx = unused * 3
                tray_gy = 2 * N + 2
                dx, dy = _grid_to_display(env, tray_gx, tray_gy)
                env.perform_action(ActionInput(id=_GA.ACTION6, data={"x": dx, "y": dy}))
                steps += 1
                board_gx = tx * 2
                board_gy = ty * 2
                dx, dy = _grid_to_display(env, board_gx, board_gy)
                fd = env.perform_action(ActionInput(id=_GA.ACTION6, data={"x": dx, "y": dy}))
                steps += 1
                if fd.state == _GS.WIN or fd.levels_completed > prev_score:
                    break
            optimal.append(steps)
            if env._state == _GS.WIN:
                break
            if env._state == _GS.GAME_OVER:
                return None
        if env._state != _GS.WIN:
            return None
        return optimal

    def patched_verify_and_report(self, env):
        if getattr(env, "game_id", None) == "polarity_tiles":
            optimal = _domain_solve(env)
            if optimal is not None:
                return {
                    "game_id": env.game_id,
                    "num_levels": env.num_levels,
                    "all_solvable": True,
                    "levels": {
                        i + 1: {
                            "solvable": True,
                            "optimal_steps": optimal[i],
                            "states_explored": 0,
                            "elapsed_ms": 0.0,
                            "notes": "polarity_tiles domain solver",
                        }
                        for i in range(len(optimal))
                    },
                    "optimal_steps_by_level": {i + 1: optimal[i] for i in range(len(optimal))},
                    "total_optimal_steps": sum(optimal),
                }
        return _orig_verify_and_report(self, env)

    BFSSolver.verify_and_report = patched_verify_and_report
    BFSSolver._polarity_tiles_patched = True


_polarity_tiles_install_domain_solver()


# ---------------------------------------------------------------------------
# Palette constants — index into the 16-colour engine palette
# ---------------------------------------------------------------------------
COLOR_BG       = 0
COLOR_BLUE     = 1
COLOR_RED      = 2
COLOR_YELLOW   = 4
COLOR_GRAY     = 5
COLOR_MAGENTA  = 6
COLOR_ORANGE   = 7
COLOR_LBLUE    = 8
COLOR_LGREEN   = 12
COLOR_LGRAY    = 13
COLOR_WHITE    = 15

# Polarity-correlated colour pools. The marker pixel is the authoritative
# polarity signal; the warm/cool colour split is a redundant cue so a player
# who's only glanced at the legend can still read the board at a distance.
POS_COLORS = [COLOR_RED, COLOR_YELLOW, COLOR_ORANGE]
NEG_COLORS = [COLOR_BLUE, COLOR_MAGENTA, COLOR_LBLUE]


# ---------------------------------------------------------------------------
# Level configuration table — one entry per difficulty
# ---------------------------------------------------------------------------
LEVEL_CONFIGS = [
    # N = logical board side length (so board is N x N logical cells)
    # tiles >= targets + 2 so the player has slack for one-or-two mistakes
    {'N':  6, 'targets':  3, 'tiles':  5, 'walls': 1, 'name': 'Easy'},
    {'N':  8, 'targets':  5, 'tiles':  7, 'walls': 3, 'name': 'Medium'},
    {'N': 10, 'targets':  7, 'tiles':  9, 'walls': 4, 'name': 'Hard'},
    {'N': 12, 'targets': 10, 'tiles': 12, 'walls': 7, 'name': 'Very Hard'},
]


def _grid_dims(cfg: dict) -> tuple[int, int]:
    """Compute (grid_w, grid_h) for a level config.

    Each logical cell renders as a 2x2 grid block (so the 1-pixel polarity
    marker is large enough to read after the camera's nearest-neighbour
    upscale). Layout under the board:

        rows 0 .. 2N-1     : board (N x N logical cells, each 2x2 grid)
        row  2N            : gray separator line
        row  2N+1          : selection-marker row (1 grid pixel tall)
        rows 2N+2 .. 2N+3  : tray (single row of 2x2 logical tile slots)

    Tray slots are laid out as [tile (2 wide)][gap (1 wide)] repeating, with
    no trailing gap after the last tile. So tray width = tiles*3 - 1.
    """
    N = cfg['N']
    board_w = 2 * N
    board_h = 2 * N
    tray_w = cfg['tiles'] * 3 - 1
    grid_w = max(board_w, tray_w)
    grid_h = board_h + 1 + 1 + 2  # board + separator + sel-marker + 2-row tray
    return grid_w, grid_h


def _build_levels() -> list[Level]:
    return [
        Level(sprites=[], grid_size=_grid_dims(cfg), name=cfg['name'])
        for cfg in LEVEL_CONFIGS
    ]


# ---------------------------------------------------------------------------
# Hand-tuned fallback layouts.
#
# These are reached only if random generation fails 200 times for a given
# (seed, level) — which it shouldn't, since _try_generate is constructive
# (non-adjacent targets always fit in the configured grid sizes). But the
# CLAUDE.md spec mandates a guaranteed fallback, so here it is.
# ---------------------------------------------------------------------------
FALLBACK_LAYOUTS = [
    {  # Level 1 (Easy)
        'N': 6,
        'targets': {(1, 1), (4, 1), (2, 4)},
        'walls': {(3, 3)},
        'tray': [
            {'color': COLOR_RED,     'polarity': '+'},
            {'color': COLOR_BLUE,    'polarity': '-'},
            {'color': COLOR_YELLOW,  'polarity': '+'},
            {'color': COLOR_MAGENTA, 'polarity': '-'},
            {'color': COLOR_ORANGE,  'polarity': '+'},
        ],
    },
    {  # Level 2 (Medium)
        'N': 8,
        'targets': {(1, 1), (4, 1), (6, 3), (1, 5), (5, 6)},
        'walls': {(2, 3), (5, 4), (3, 6)},
        'tray': [
            {'color': COLOR_RED,     'polarity': '+'},
            {'color': COLOR_BLUE,    'polarity': '-'},
            {'color': COLOR_YELLOW,  'polarity': '+'},
            {'color': COLOR_MAGENTA, 'polarity': '-'},
            {'color': COLOR_ORANGE,  'polarity': '+'},
            {'color': COLOR_LBLUE,   'polarity': '-'},
            {'color': COLOR_RED,     'polarity': '+'},
        ],
    },
    {  # Level 3 (Hard)
        'N': 10,
        'targets': {(1, 1), (4, 1), (8, 1), (1, 4), (5, 4), (8, 5), (4, 8)},
        'walls': {(2, 6), (6, 2), (7, 7), (3, 3)},
        'tray': [
            {'color': COLOR_RED,     'polarity': '+'},
            {'color': COLOR_BLUE,    'polarity': '-'},
            {'color': COLOR_YELLOW,  'polarity': '+'},
            {'color': COLOR_MAGENTA, 'polarity': '-'},
            {'color': COLOR_ORANGE,  'polarity': '+'},
            {'color': COLOR_LBLUE,   'polarity': '-'},
            {'color': COLOR_RED,     'polarity': '+'},
            {'color': COLOR_BLUE,    'polarity': '-'},
            {'color': COLOR_YELLOW,  'polarity': '+'},
        ],
    },
    {  # Level 4 (Very Hard)
        'N': 12,
        'targets': {(1, 1), (4, 1), (8, 1), (10, 1),
                    (1, 5), (5, 5), (9, 5),
                    (1, 9), (5, 9), (10, 9)},
        'walls': {(3, 3), (7, 3), (10, 3),
                  (3, 7), (7, 7),
                  (3, 10), (8, 10)},
        'tray': [
            {'color': COLOR_RED,     'polarity': '+'},
            {'color': COLOR_BLUE,    'polarity': '-'},
            {'color': COLOR_YELLOW,  'polarity': '+'},
            {'color': COLOR_MAGENTA, 'polarity': '-'},
            {'color': COLOR_ORANGE,  'polarity': '+'},
            {'color': COLOR_LBLUE,   'polarity': '-'},
            {'color': COLOR_RED,     'polarity': '+'},
            {'color': COLOR_BLUE,    'polarity': '-'},
            {'color': COLOR_YELLOW,  'polarity': '+'},
            {'color': COLOR_MAGENTA, 'polarity': '-'},
            {'color': COLOR_ORANGE,  'polarity': '+'},
            {'color': COLOR_LBLUE,   'polarity': '-'},
        ],
    },
]


# ===========================================================================
# Game class
# ===========================================================================
class PolarityTilesGame(BaseGame):
    """Click-and-place puzzle: cover all targets without losing too many tiles."""

    game_name      = "Polarity Tiles"
    description    = (
        "Click a tile in the tray to select it, then click an empty board cell "
        "to place it. Cover every light-green target cell to win. Adjacent tiles "
        "react: same polarity repels (and may fly off the board, gone for good); "
        "opposite polarity locks them together. Press Z to undo your last "
        "placement (one step only)."
    )
    category       = "non_agentic"
    primitive_tags = ["click", "spatial_assembly", "polarity"]
    feedback_tier  = 2

    def __init__(self, seed: int = 0) -> None:
        # RNG must exist BEFORE super().__init__() because BaseGame.__init__
        # calls set_level(0) -> on_set_level(level), which uses _make_level_rng.
        self._rng = random.Random(seed)

        # Pre-init mutable state holders (overwritten by on_set_level).
        # Note: BaseGame already owns `_state` for GameState (NOT_FINISHED/WIN/...),
        # so our level-data dict lives under `_world` to avoid clobbering it.
        self._N: int = 0
        self._grid_w: int = 0
        self._grid_h: int = 0
        self._world: dict = {}
        self._selected_idx: Optional[int] = None
        self._undo_snapshot: Optional[dict] = None
        self._undo_selected: Optional[int] = None

        # Camera dimensions are placeholders — the engine resizes the camera
        # per-level in set_level() because each Level carries its own grid_size.
        # Use the largest level's dims so the initial allocation is safe.
        max_w = max(_grid_dims(c)[0] for c in LEVEL_CONFIGS)
        max_h = max(_grid_dims(c)[1] for c in LEVEL_CONFIGS)

        camera = Camera(
            background=COLOR_BG,
            letter_box=COLOR_LGRAY,
            width=max_w,
            height=max_h,
        )

        super().__init__(
            game_id="polarity_tiles",
            levels=_build_levels(),
            camera=camera,
            available_actions=[6, 7],   # ACTION6 click + ACTION7 undo (RESET is implicit)
            seed=seed,
        )

    # -----------------------------------------------------------------------
    # Determinism helper. Every random draw inside on_set_level uses an RNG
    # derived from this — never the global random module, never time/uuid.
    # -----------------------------------------------------------------------
    def _make_level_rng(self) -> random.Random:
        # The 997 multiplier is just a small prime to spread (seed, level)
        # pairs across the int space and avoid trivial correlations like
        # "level N of seed 0 looks like level 0 of seed N".
        return random.Random(self._seed * 997 + self.level_index)

    # -----------------------------------------------------------------------
    # Level setup
    # -----------------------------------------------------------------------
    def on_set_level(self, level: Level) -> None:
        """Populate the level — called by the engine on init and on level change.

        Reset is also routed through here (engine clones from _clean_levels then
        calls set_level), so the regenerated layout is identical to the original
        for the same (seed, level_index) — which is exactly what the verifier
        requires for action replay.
        """
        cfg = LEVEL_CONFIGS[self.level_index]
        self._N = cfg['N']
        self._grid_w, self._grid_h = _grid_dims(cfg)

        level_rng = self._make_level_rng()

        # Try up to 200 randomised layouts; fall back to a hand-tuned layout
        # if every attempt failed solvability. With non-adjacent target
        # placement this fallback should never trigger, but it's required by
        # the Mouse Cloudy spec.
        layout = None
        for _attempt in range(200):
            sub_rng = random.Random(level_rng.randint(0, 10**9))
            candidate = self._try_generate(sub_rng, cfg)
            if candidate is not None and self._solver_check(candidate):
                layout = candidate
                break
        if layout is None:
            layout = copy.deepcopy(FALLBACK_LAYOUTS[self.level_index])

        # Materialise into the live game state.
        self._world = {
            'targets': set(layout['targets']),
            'walls':   set(layout['walls']),
            'tray':    [dict(t, used=False) for t in layout['tray']],
            'board':   {},
        }
        self._selected_idx  = None
        self._undo_snapshot = None
        self._undo_selected = None

        self._render_state()

    def _try_generate(self, sub_rng: random.Random, cfg: dict) -> Optional[dict]:
        """Generate a candidate layout. Returns None if non-adjacent targets
        couldn't be packed (extremely unlikely at the configured sizes).

        Construction guarantees:
          - No two targets are orthogonally adjacent. So placing one tile per
            target in any order never triggers a reaction between targets.
          - Walls never sit ON a target (would make it uncoverable). They MAY
            sit adjacent to a target — walls don't react with tiles, so this
            is harmless.
        """
        N = cfg['N']
        cells = [(x, y) for x in range(N) for y in range(N)]
        sub_rng.shuffle(cells)

        targets: list[tuple[int, int]] = []
        forbidden: set[tuple[int, int]] = set()
        for cell in cells:
            if cell in forbidden:
                continue
            targets.append(cell)
            forbidden.add(cell)
            for dx, dy in ((-1, 0), (1, 0), (0, -1), (0, 1)):
                nb = (cell[0] + dx, cell[1] + dy)
                if 0 <= nb[0] < N and 0 <= nb[1] < N:
                    forbidden.add(nb)
            if len(targets) >= cfg['targets']:
                break
        if len(targets) < cfg['targets']:
            return None

        target_set = set(targets)
        wall_candidates = [c for c in cells if c not in target_set]
        sub_rng.shuffle(wall_candidates)
        walls = set(wall_candidates[:cfg['walls']])

        tray = []
        for _ in range(cfg['tiles']):
            if sub_rng.random() < 0.5:
                tray.append({'color': sub_rng.choice(POS_COLORS), 'polarity': '+'})
            else:
                tray.append({'color': sub_rng.choice(NEG_COLORS), 'polarity': '-'})

        return {'N': N, 'targets': target_set, 'walls': walls, 'tray': tray}

    def _solver_check(self, layout: dict) -> bool:
        """Verify the layout is solvable by direct placement.

        Defensive simulation: walk through targets in order, place a tile on
        each, and confirm no two placements are adjacent (which would trigger
        a reaction and potentially break the trivial solution). With the
        non-adjacent target invariant this always returns True, but we
        re-check it explicitly so a future change to _try_generate that
        breaks the invariant fails loudly here instead of leaving an
        unsolvable level for the player to discover.
        """
        if len(layout['tray']) < len(layout['targets']):
            return False
        targets = list(layout['targets'])
        walls = layout['walls']
        placed: set = set()
        for t in targets:
            if t in walls:
                return False
            for dx, dy in ((-1, 0), (1, 0), (0, -1), (0, 1)):
                if (t[0] + dx, t[1] + dy) in placed:
                    return False  # would trigger a reaction — invariant broken
            placed.add(t)
        return True

    # -----------------------------------------------------------------------
    # Action dispatch
    # -----------------------------------------------------------------------
    def step(self) -> None:
        action_id = self.action.id

        if action_id == GameAction.ACTION6:
            self._handle_click()
        elif action_id == GameAction.ACTION7:
            self._handle_undo()
        # Any other action id (or no-op) — fall through to complete_action so
        # the engine sees one resolved frame.
        self.complete_action()

    # -----------------------------------------------------------------------
    # Click routing
    # -----------------------------------------------------------------------
    def _handle_click(self) -> None:
        dx_disp = self.action.data.get('x', 0)
        dy_disp = self.action.data.get('y', 0)
        coords = self.camera.display_to_grid(dx_disp, dy_disp)
        if coords is None:
            return  # Click landed in the letterbox area.

        gx, gy = coords
        N = self._N

        # Board area: rows 0..2N-1, cols 0..2N-1 (each 2x2 grid block = 1 logical cell).
        if 0 <= gy < 2 * N and 0 <= gx < 2 * N:
            self._handle_board_click(gx // 2, gy // 2)
            return

        # Tray area: rows 2N+2 and 2N+3.
        if 2 * N + 2 <= gy <= 2 * N + 3:
            # Slot k spans grid x ∈ {3k, 3k+1}; gap pixel at 3k+2.
            if gx % 3 == 2:
                return  # Click on inter-slot gap — ignore.
            tile_idx = gx // 3
            if 0 <= tile_idx < len(self._world['tray']):
                self._handle_tray_click(tile_idx)
            return
        # Anywhere else (separator row, marker row, dead space): ignore.

    def _handle_tray_click(self, idx: int) -> None:
        if self._world['tray'][idx]['used']:
            return  # Spent tile — no selection change.
        self._selected_idx = idx
        self._render_state()

    def _handle_board_click(self, lx: int, ly: int) -> None:
        if self._selected_idx is None:
            return  # Nothing selected — clicks on the board are no-ops.
        if (lx, ly) in self._world['walls']:
            return  # Walls block placement.
        if (lx, ly) in self._world['board']:
            return  # Cell already occupied by a tile.

        # Snapshot for one-step undo BEFORE mutating anything. deepcopy so the
        # snapshot is fully independent of subsequent mutations.
        self._undo_snapshot = copy.deepcopy(self._world)
        self._undo_selected = self._selected_idx

        idx = self._selected_idx
        tile = self._world['tray'][idx]
        tile['used'] = True
        self._world['board'][(lx, ly)] = {
            'color':       tile['color'],
            'polarity':    tile['polarity'],
            'locked':      False,
            'tray_origin': idx,
        }

        self._resolve_reactions((lx, ly))

        self._selected_idx = None
        self._check_end()
        self._render_state()

    def _handle_undo(self) -> None:
        if self._undo_snapshot is None:
            return
        self._world         = self._undo_snapshot
        self._selected_idx  = self._undo_selected
        self._undo_snapshot = None
        self._undo_selected = None
        self._render_state()

    # -----------------------------------------------------------------------
    # Reaction resolution
    #
    # Iterate the 4 orthogonal neighbours in fixed order (UP, RIGHT, DOWN,
    # LEFT). For each neighbour cell that contains a tile, fire one reaction.
    # Reactions never cascade — a tile sliding into a new neighbourhood does
    # NOT trigger fresh reactions there.
    #
    # The placed tile's identity is tracked by its original position `pos`.
    # If during a reaction the placed tile leaves `pos` (slid to a new cell or
    # was removed off-board), we abort the rest of the loop — the placed tile
    # is no longer at `pos` to react with the remaining neighbours. If the
    # placed tile gets LOCKED (opposite-polarity reaction), it stays at `pos`
    # and continues participating, but its `locked=True` flag prevents it
    # from flying in any subsequent same-polarity reaction.
    # -----------------------------------------------------------------------
    def _resolve_reactions(self, pos: tuple[int, int]) -> None:
        DIRS = [(0, -1), (1, 0), (0, 1), (-1, 0)]   # up, right, down, left
        for dx, dy in DIRS:
            if pos not in self._world['board']:
                return  # Placed tile moved or was removed; stop.
            placed = self._world['board'][pos]

            npos = (pos[0] + dx, pos[1] + dy)
            if npos not in self._world['board']:
                continue
            neighbor = self._world['board'][npos]

            if neighbor['polarity'] == placed['polarity']:
                self._react_same(pos, npos, dx, dy)
            else:
                # Opposite polarity: both lock in place.
                placed['locked']   = True
                neighbor['locked'] = True

    def _react_same(self, p_pos: tuple[int, int], n_pos: tuple[int, int],
                    dx: int, dy: int) -> None:
        """Same-polarity repulsion. Direction `(dx, dy)` points from placed to
        neighbour. So placed flies in `(-dx, -dy)` (away from neighbour) and
        neighbour flies in `(dx, dy)` (away from placed). Locked tiles don't
        fly but their counterpart still does."""
        board = self._world['board']
        placed   = board[p_pos]
        neighbor = board[n_pos]

        if not placed['locked']:
            occupied = self._occupied_set()
            occupied.discard(p_pos)            # placed leaves its cell first
            final = self._slide(p_pos, (-dx, -dy), occupied)
            if final is None:
                # Flew off the board — REMOVED permanently.
                del board[p_pos]
            elif final != p_pos:
                board[final] = board.pop(p_pos)

        if not neighbor['locked']:
            occupied = self._occupied_set()    # rebuilt — reflects placed's new state
            occupied.discard(n_pos)
            final = self._slide(n_pos, (dx, dy), occupied)
            if final is None:
                del board[n_pos]
            elif final != n_pos:
                board[final] = board.pop(n_pos)

    def _occupied_set(self) -> set[tuple[int, int]]:
        """Cells that block a sliding tile: all walls plus all currently-placed tiles."""
        return set(self._world['board'].keys()) | self._world['walls']

    def _slide(self, start: tuple[int, int], direction: tuple[int, int],
               occupied: set[tuple[int, int]]) -> Optional[tuple[int, int]]:
        """Slide from `start` in `direction` until something stops the tile.

        Returns:
            (x, y)  — the last empty cell before an obstacle.
            start   — if the tile is blocked immediately and can't move at all.
            None    — if the path to the board edge is unobstructed: the tile
                      flies off and is REMOVED (this is the irreversible-action
                      lever the user playtests around).
        """
        N = self._N
        dx, dy = direction
        x, y = start
        moved = False
        while True:
            nx, ny = x + dx, y + dy
            if not (0 <= nx < N and 0 <= ny < N):
                # Reached the edge with nothing stopping us → REMOVED.
                return None
            if (nx, ny) in occupied:
                if not moved:
                    return start          # Couldn't budge — stays put.
                return (x, y)
            x, y = nx, ny
            moved = True

    # -----------------------------------------------------------------------
    # Win/lose detection
    # -----------------------------------------------------------------------
    def _check_end(self) -> None:
        targets = self._world['targets']
        board_positions = set(self._world['board'].keys())
        if all(t in board_positions for t in targets):
            self.next_level()
            return
        unused = [t for t in self._world['tray'] if not t['used']]
        if not unused:
            self.lose()

    # -----------------------------------------------------------------------
    # Rendering — rebuild every sprite from self._world on each state change
    # so we never drift between data model and visuals.
    # -----------------------------------------------------------------------
    def _render_state(self) -> None:
        level = self.current_level
        level.remove_all_sprites()

        N = self._N
        gw = self._grid_w

        # Layer 0: targets (light green). Each logical target = 2x2 grid block.
        # Layer 1: walls (gray) and tray tiles. Layer 2: placed tiles cover
        # targets. Layer 3: selection marker overlays the tray.
        for (tx, ty) in self._world['targets']:
            level.add_sprite(Sprite(
                pixels=[[COLOR_LGREEN, COLOR_LGREEN],
                        [COLOR_LGREEN, COLOR_LGREEN]],
                name=f'target_{tx}_{ty}',
                x=tx * 2, y=ty * 2,
                layer=0,
                tags=['target'],
            ))

        for (wx, wy) in self._world['walls']:
            level.add_sprite(Sprite(
                pixels=[[COLOR_GRAY, COLOR_GRAY],
                        [COLOR_GRAY, COLOR_GRAY]],
                name=f'wall_{wx}_{wy}',
                x=wx * 2, y=wy * 2,
                layer=1,
                tags=['wall'],
            ))

        for (bx, by), tile in self._world['board'].items():
            color  = tile['color']
            marker = COLOR_WHITE if tile['polarity'] == '+' else COLOR_BG
            # Locked tiles get a subtle gray pixel in the bottom-right corner
            # so the player can see WHY a tile didn't move during a chain.
            corner = COLOR_LGRAY if tile['locked'] else color
            level.add_sprite(Sprite(
                pixels=[[marker, color],
                        [color,  corner]],
                name=f'btile_{bx}_{by}',
                x=bx * 2, y=by * 2,
                layer=2,
                tags=['btile'],
            ))

        # Separator row across the full grid width — gray bar under the board.
        level.add_sprite(Sprite(
            pixels=[[COLOR_GRAY] * gw],
            name='separator',
            x=0, y=2 * N,
            layer=0,
            tags=['ui'],
        ))

        # Tray. Each unused tile renders as a 2x2 block at (idx*3, 2N+2).
        # Tagged 'sys_click' so the engine's click-action enumerator knows
        # these are valid click targets (used by debugging tools / agents).
        tray_y = 2 * N + 2
        for i, tile in enumerate(self._world['tray']):
            if tile['used']:
                continue
            color  = tile['color']
            marker = COLOR_WHITE if tile['polarity'] == '+' else COLOR_BG
            level.add_sprite(Sprite(
                pixels=[[marker, color],
                        [color,  color]],
                name=f'tray_{i}',
                x=i * 3, y=tray_y,
                layer=1,
                tags=['sys_click', 'tray_tile'],
            ))

        # Selection marker — two white pixels above the selected tray slot.
        if self._selected_idx is not None:
            sx = self._selected_idx * 3
            level.add_sprite(Sprite(
                pixels=[[COLOR_WHITE, COLOR_WHITE]],
                name='selection_marker',
                x=sx, y=2 * N + 1,
                layer=3,
                tags=['ui'],
            ))
